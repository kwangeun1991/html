window.addEventListener('DOMContentLoaded',function(e){
  /*메인배너롤링*/
  var swiper = new Swiper('.main_banner .swiper-container', {
        navigation: {
          nextEl: '.main_banner .navi.next',
          prevEl: '.main_banner .navi.prev',
        },
        speed: 2000,
        loop: true,
        autoplay: {
          delay: 3000,
        },
      });
  /*메인배너롤링*/
    /*메인상품롤링*/
      var swiperGoods = new Swiper('.goods_rolling .swiper-container', {
      slidesPerView: 4,
      spaceBetween: 18,
      loop: true,
      navigation: {
        nextEl: '.goods_rolling .navi.next',
        prevEl: '.goods_rolling .navi.prev',
      },
    });
    /*메인상품롤링*/
},false);
