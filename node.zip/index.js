/*
변수 -> 그릇
var a =1;
a그릇 = 1 을 담는다
-> 메모리(그릇)에 1이 담겨지는 것

선언자를 쓰면 변수가 된다
변수
var
let
예)
var a;
var b;
값을 담아야 연산을 할 수 있다

var -> 일반
let -> 지역 변수에 특화된 선언자

지역변수 -> 함수

const

1, 2, 3 -> 변하는 수

상수 -> 변경할 수 없는 수
const -> 일반 값은 변경 할 수 없음
      -> 객체에서는 변경가능

변수 선언자
var
let

상수 선언자
const

연산자
var c = a + b;(+ -> 연산자)

1. 산술 연산자
(+, -, /, *, % - 나머지)
1,3,5 % 2==1 (홀수를 나누면 1)
0,2,4,6 % 2 ==0 (짝수를 나누면 0)

2. 대입연산자
 = (값을 할당, 또는 복사)

3. 증감연산자
변수++
1. 증가하기 전 대입
2. 대입 후 증가

++변수
1. 증가 먼저
2. 대입

변수--
1. 대입 먼저
2. 대입 후 감소

--변수
1. 감소 먼저
2. 대입

점점 증가, 점점 감소


4. 비교연산자
비교
> >=
< <=
==,(같다) ===
!=,(다르다) !==

논리값
true (참), false(거짓)


5. 논리 연산자
|| -> OR -> 합집합
- 비교대상 둘중 하나만 참이여도 모두 참

&& -> AND -> 교집합
- 비교 대상 둘다 모두 참이여야 참

! -> NOT(부정)
true -> false
false -> true


변수 = 값 -> 대입

1. 문자 "school"
2. 숫자 1, 2, 3, 4
3. 논리값 true ,false
3. null -> 아무것도 없다 -> 빈값
5. undefined -> 정의 되지 않았다
  (값)
  -선언은 되어 있는데 값이 대입되지 않음
  -변수를 선언만 하면 undefined "값"이 대입 된다. 얘도 값이다.
6. 객체
1~5 -> 원시값
6 객체

전역변수에 변수를 선언하면 변수가 가장위로 올라간다

원시값 -> window

값을 대입하면 올라가지 않는다

7. 삼항 연산자
(true(참)) ? 참일때 처리 : 거짓일때 처리

(조건식)?참 :거짓


변수 -> 변수명
변수명 규칙
1. a~z(대소문자), _ , 숫자, $
2. 한글(ㅇ)-> 쓰지 않기로
2. 숫자는 변수명 첫글자로 올수 없음
3. 예약어
(자바스크립트 내에서 이미 정의되어 있는 키워드)
new,

on(이벤트명)을 대입(=)

addEventListener -> 이벤트를 추가
button.addEventListener('이벤트명',이벤트발생시 실행부분, 버블링여부)


HTML 태그를 선택하는 방법
1. 속성 ID 로 찾아서 선택하는 방법  (단수)
<div id='id1'></div>
document.getElementById("아이디명");

2. 속성 class로 찾아서 선택하는 방법   (복수)
<div class='cl1'></div>
document.getElementsByClassName("클래스명");

3. 태그명(div, li, button, ....)  (복수)
document.getElementsByTagName("태그명");

4. name 속성으로 선택 (복수)
<input type='text' name='idnm'>
document.getElementsByName("name 속성명");


CSS문법으로 HTML 선택
document.querySelector -> 가장 처음매칭 되는 HTML 요소

document.querySelectorAll -> 매칭되는 전부 선택



1. ID 속성 - 단수 선택
document.getElementById("아이디명");

2. class 속성 - 복수 선택
document.getElementsByClassName("클래스명");

3. 태그명 - 복수 선택
document.getElementsByTagName("태그명");

4. name 속성 - 복수 선택
document.getElementsByName("name 속성명");

5. CSS 문법으로 선택
document.querySelector("CSS 선택자"); - 단수 선택
document.querySelectorAll("CSS 선택자"); - 복수 선택


요소.addEventListener("이벤트명", 이벤트 발생시 실행 부분, 버블링 여부);

1. 캡쳐링
2. 버블링 -> 기본값

버블링 -> 이벤트 전파

1. 요소선택.on이벤트 = function() {

}; ->대입(여러개 입력시 마지막것이 실행)

2. 요소선택.addEventListener("이벤트명", function(){

});

1번보다는 2번 권장































*/
