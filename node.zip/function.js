/*
var a = 10;
var b = 20;

abc(a,b);
abc1(a,b);

function abc( a, b) {
  a = a+ 2;
  b=b+3;
  console.log('a',a);
  console.log('b',b);
}

function abc1( a, b) {
  a=a+4;
  b = b + 5;
  console.log('a',a);
  console.log('b',b);
}

console.log('a',a);
console.log('b',b);


abc();

function abc() {
   a = 15;
   b = 25;

  console.log('a',a);
  console.log('b',b);


}

console.log('a',a);
console.log('b',b);



let a = 10;
let b = 20;

{
   a = 15;
   b = 25;
  console.log('a',a);
  console.log('b',b);

}


console.log('a',a);
console.log('b',b);



var a = 100;
for ( var i = 0; i <100; i++) {
  var a = i;

  console.log('for a',a);
}

console.log('a',a);


var a = 10;
var b = 20;

function abc (a, b){
  var a += 5;
  var b += 10;
  console.log('지역a',a);
  console.log('지역b',b);
}

console.log('전역a',a);
console.log('전역b',b);

*/
