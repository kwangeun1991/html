setInterval(function(){
  let date = new Date();
  let hour = date.getHours();
  let mins = date.getMinutes();
  let sec = date.getSeconds();
  const str = `${hour}:${mins}:${sec}`;
  console.log(str);
}, 1000);
