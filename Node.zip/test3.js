for( let a = 1; a < 10; a++ ) {
  console.log(`-----${a}단------`)
  for(let b = 1; b < 10; b++ ) {
    console.log(`${a}X${b} = ${a*b}`);
  }
}
