const students = [
  {name:"이름1",score:80},
  {name:"이름2",score:90},
  {name:"이름3",score:60},
  {name:"이름4",score:70},
  {name:"이름5",score:50},
];

students.forEach((value) =>{
  console.log(value);
});

function getGrade(score){
  let grade = "D";
  if(score >= 90) {
    grade = "A";
  } else if (score )
}
