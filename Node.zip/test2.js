let fruit = 'apple';
console.log('fruit:', fruit);

fruit = 'grape';
console.log('fruit:', fruit);
