<?php
//header("Access-Control-Allow-Origin: *");

echo "<img src='image/banner{$_GET['num']}.jpg'>";
