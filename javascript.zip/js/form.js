/*

상품 추가 양식

@author 작성자 이름.....


*/

const goodsForm = {
  /*
양식추가



  */
  add : function() {
    $html = $('#form .goods').first().clone();
    const deleteBtn = '<button class='remove'>삭제</button>';
    $html.find('.btns').append(deleteBtn);

    $html.find('input[type='text']')

    $('#form').append(html);
  },

  /*
양식제거
  */
  remove : function(){

  }
};

$(()=>{
  $('body').on('.goods .add .click',function(e){
    goodsForm.add();
    e.preventDefault;
  });

  $('.goods .remove').click(function(){
    goodsForm.remove();
  });
});
