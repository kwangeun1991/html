/*




상하이동버튼




*/


$(()=>{
  $('.go_btns .btn').click(function(){
    let scrollTop=0; //상단일때

    if($(this).hasClass('bottom')){
      //하단이동
      scrollTop=$('body').outerHeight();
    }

    $('html, body').animate({
      scrollTop:scrollTop + 'px'
    },300);
  });
});
