변수 -> 그릇
var a =1;
a그릇 = 1 을 담는다
-> 메모리(그릇)에 1이 담겨지는 것

선언자를 쓰면 변수가 된다
변수
var
let
예)
var a;
var b;
값을 담아야 연산을 할 수 있다

var -> 일반
let -> 지역 변수에 특화된 선언자

지역변수 -> 함수

const

1, 2, 3 -> 변하는 수

상수 -> 변경할 수 없는 수
const -> 일반 값은 변경 할 수 없음
      -> 객체에서는 변경가능

변수 선언자
var
let

상수 선언자
const

연산자
var c = a + b;(+ -> 연산자)

1. 산술 연산자
(+, -, /, *, % - 나머지)
1,3,5 % 2==1 (홀수를 나누면 1)
0,2,4,6 % 2 ==0 (짝수를 나누면 0)

2. 대입연산자
 = (값을 할당, 또는 복사)

3. 증감연산자
변수++
1. 증가하기 전 대입
2. 대입 후 증가

++변수
1. 증가 먼저
2. 대입

변수--
1. 대입 먼저
2. 대입 후 감소

--변수
1. 감소 먼저
2. 대입

점점 증가, 점점 감소


4. 비교연산자
비교
> >=
< <=
==,(같다) ===
!=,(다르다) !==

논리값
true (참), false(거짓)


5. 논리 연산자
|| -> OR -> 합집합
- 비교대상 둘중 하나만 참이여도 모두 참

&& -> AND -> 교집합
- 비교 대상 둘다 모두 참이여야 참

! -> NOT(부정)
true -> false
false -> true


변수 = 값 -> 대입

1. 문자 "school"
2. 숫자 1, 2, 3, 4
3. 논리값 true ,false
3. null -> 아무것도 없다 -> 빈값
5. undefined -> 정의 되지 않았다
  (값)
  -선언은 되어 있는데 값이 대입되지 않음
  -변수를 선언만 하면 undefined "값"이 대입 된다. 얘도 값이다.
6. 객체
1~5 -> 원시값
6 객체

전역변수에 변수를 선언하면 변수가 가장위로 올라간다

원시값 -> window

값을 대입하면 올라가지 않는다

7. 삼항 연산자
(true(참)) ? 참일때 처리 : 거짓일때 처리

(조건식)?참 :거짓


변수 -> 변수명
변수명 규칙
1. a~z(대소문자), _ , 숫자, $
2. 한글(ㅇ)-> 쓰지 않기로
2. 숫자는 변수명 첫글자로 올수 없음
3. 예약어
(자바스크립트 내에서 이미 정의되어 있는 키워드)
new,

on(이벤트명)을 대입(=)

addEventListener -> 이벤트를 추가
button.addEventListener('이벤트명',이벤트발생시 실행부분, 버블링여부)


HTML 태그를 선택하는 방법
1. 속성 ID 로 찾아서 선택하는 방법  (단수)
<div id='id1'></div>
document.getElementById("아이디명");

2. 속성 class로 찾아서 선택하는 방법   (복수)
<div class='cl1'></div>
document.getElementsByClassName("클래스명");

3. 태그명(div, li, button, ....)  (복수)
document.getElementsByTagName("태그명");

4. name 속성으로 선택 (복수)
<input type='text' name='idnm'>
document.getElementsByName("name 속성명");


CSS문법으로 HTML 선택
document.querySelector -> 가장 처음매칭 되는 HTML 요소

document.querySelectorAll -> 매칭되는 전부 선택



1. ID 속성 - 단수 선택
document.getElementById("아이디명");

2. class 속성 - 복수 선택
document.getElementsByClassName("클래스명");

3. 태그명 - 복수 선택
document.getElementsByTagName("태그명");

4. name 속성 - 복수 선택
document.getElementsByName("name 속성명");

5. CSS 문법으로 선택
document.querySelector("CSS 선택자"); - 단수 선택
document.querySelectorAll("CSS 선택자"); - 복수 선택


요소.addEventListener("이벤트명", 이벤트 발생시 실행 부분, 버블링 여부);

1. 캡쳐링
2. 버블링 -> 기본값

버블링 -> 이벤트 전파

1. 요소선택.on이벤트 = function() {

}; ->대입(여러개 입력시 마지막것이 실행)

2. 요소선택.addEventListener("이벤트명", function(){

});

1번보다는 2번 권장



function 함수명(인수,인수,인수,...) {
//프로그램 처리하는 부분

return 반환하는 부분
}


함수명(인자,인자,...);(세미콜론) ->호출

함수를 호출했을때 인수 = (대입) 인자 (값이 복사)
var a = 1; // 전역변수
var b = 2; // 전역변수

abc(a, b); ->호출
abc - 지역변수 a = 전역변수 a; (복사)
abc - 지역변수 b = 전역변수 b; (복사)
function abc ((지역변수)a=(전역변수)a, (지역번수)b=(전역변수)b){
  a - 지역변수
  b - 지역변수
  var c= a + b;

  return c;
}

함수를 사용하는 이유
1. 반복되는 작업을 단순화 할 수 있다.


window.a        object -> 서로 다른 주소 생성이 되어 있다.
var a       =    {};
주소 1           주소 10

var a = {} 를 접근할 수 있는 주소를 저장(주소 10) -> 참조
주소를 찾는 것 -> 참조


함수 리터럴 = 익명함수
var abc = function () {//익명함수};

  변수= 익명함수 대입하는 형태 -> 함수 리터럴

var a = {
    변수         대입    익명함수
  getMemberLogin  :   function(){

  }
}



var member = {
  memid : "kwangeun", // 대상 - 변수
  address: "주소.....",// 대상 - 변수

  변수         대입    익명함수
  getMemberLogin : function(){ //메서드

  }
}


객체 리터럴 -> 메서드
속성 : function() {

}

즉시 실행함수
런타임이 시작되었을 때 바로 실행
-> 호출할 필요가 없음
-> 함수명을 만들 필요가 없다.(익명함수)
-> 초기화

(function(){

})();

//인수
(function(localA,localB){

)}(globalA,globalB);

//반환
var result = (function(localA,localB){
  return localA+localB;

)}(globalA,globalB);



arguments - 함수 내부에 존재하는 인수를 담고 있는 변수(배열)
            따로 선언 안되어있지만 내부적으로 존재(인수를 담고 는 변수)
            가변적인 인수를 설정할 때(인수는 1개 또는 1개 이상 ~ 몇개 올지??)

...인수 -> 가변 인수
function abc (a, ...b) {

}


객체
1. 객체 리터럴
var a ={}; //변수 a에 객체 {} 를 대입
            속성: 값, 콤마(,) 여러개 지정 가능

var a = {
  sido: "인천",
  getArea: function(){//함수 (메서드)

  }
}

2. 생성자
자바스크립트는 함수가 객체
다른 언어는 함수가 객체 X
(Function Object)

함수를 이용해서 객체를 생성할 수 있는 방식

생성 -> 호출

객체는 new 연산자를 통해서 생성
함수를 호출하면 내부적으로 new 함수명() -> 함수는 객체
-> 함수를 통해서 객체를 생성(생성자)

객체 -> 대상과 행위로 구성되어 있는 데이터 타입

함수 생성자도 대상(변수)와 행위(함수)로 구성 -> 객체니까

생성자
function Abc() {
this.a=1;
this.b=2;
}

var abc=new Abc(); (Abc를 생성하고 abc 에 대입)
abc.a --> 1 (생성 -> 접근)

객체 리터럴
var abc = {
  a:1;
  b:2;
};

{} -> new Object -> Object 생성자가 생성
var abc = new Object();

abc.a -->(바로접근가능)


생성자
-> 왜 생성이 될까?

function Abc() {
  this.a =1;
  this.b =2;
}

생성자 함수
-> prototype 객체가 있다


화살표 방식(화살표 함수)
          인수    return부분
var abc = (a, b) => a + b;


*****브라우저 자바스크립트
ECMAScript(내장객체)-> 브라우저 , nodejs

Object -> 일반객체
***********************************6개 검색해보기*******************************
String -> 문자와 관련 객체 string.prototype->메서드
Number -> 숫자와 관련된 객체 number.prototype->메서드
Boolean -> 논리값과 관련된 객체(참, 거짓)
Array -> 배열과 관련된 객체 / 한꺼번에 여러 데이터를 담을 수 있는 공간
Date -> 날짜, 시간과 관련된 객체
Math -> 수학 연산과 관련된 객체

Function -> 함수와 관련된 객체
RegExp -> 정규표헌식과 관련된 객체
Promise -> 비동기 처리와 관련 객체

브라우저객체
window ->브라우저와 관련된 객체 최상위 객체
window.document-> html 문서를 조작하는것 관련된 객체
  jQuery - DOM 라이브러리
window.screen -> 사용자화면
  portait -> 세로
  landscape -> 가로

window.history -> 방문기록관련 객체
  length -> 현재 저장된 이동한 페이지 수
  scrollRestoration 페이지 이동시 이전
                  -> auto  스크롤 상태 유지
                  -> manual  스크롤 상태 유지 X
    back() 한단계 뒤로가기
    forward() 한단계 앞으로가기
    go(숫자) -> 숫자만큼 음수(뒤로), 양수(앞으로) 이동
window.location -> 이동url 객체
  location->href->변경->페이지 이동->함수 assign
  location.href="https://naver.com";
  == location.assign("https://naver.com");
  ->이동내역이 저장(뒤로가기, 앞으로가기 동작 )
    href -> 현재 Full URL -> 변경 -> 페이지 이동
    location.assign("이동할경로") -> 페이지이동
    location.replace("이동할경로") -> 이동내역 X(뒤로가기X)
    location.reload() -> 새로고침

  location.replace("경로")
  ->이동 내역이 저장되지않는다.(뒤로가기, 앞으로가기 동작 X)

window.navigator -> 사용자사용환경(Device)

****************************************************중요*****************
window.alert -> 경고, 알림 메세지 출력***
window.prompt -> 입력창***
window.confirm -> 확인, 취소 선택창***
window.open -> 새창, 팝업 ***
window.setInterval -> 주기적으로 실행***
window.setTimeout -> 지연후 실행 ***
****************************************************중요******************
window.moveTo(x, y) -> 창을 이동
window.moveBy(x, y) -> 현재위치 기준에서 이동
window.resizeTo(width,height) -> 창의 사이즈를 변경

window 가붙는건 window 생략가능 -> window.alert(); -> alert();


var a = "abc";   //문자(원시타입, 객체 X)
var b = a.charAt(0); //a가 객체 -> charAt() 호출가능

메서드를 호출
var a = "abc" -> 메소드 호출시 -> new string("abc"); ->자동으로 객체로 전환
(래퍼(wrapper)객체)
var b = a.charAt(0); ->다시 문자로 변경

var a = "abc" -> new String("abc");

String 객체로 바뀌면 문자가 일렬로 저장(문자열)
a b c
0 1 2 -> length 3개


1. charAt -> 특정 번째 문자를 가져오는 함수
2. concat
3.startsWith
4. endsWith
5. includes
6. indexOf
7. lastIndexOf
8. repeat
9. replace
10. slice (start , end) -> start -> end -1 까지 출력
11. split
12. substring
13. toLowerCase
13. toUpperCase
14. trim
15. toString



Number
숫자를 다루는 객체

new Number() -> 문자를 숫자로 변환 (Number 객체 )
Number() -> 문자를 숫자로 변환 (숫자(원시타입))

"123" -> 문자

변환 new Number -> X (사용지양)
    Number() -> O (사용권장)

String -> new String() -> String() (문자열로 변환)
생성자로 할 경우 객체로 변함 (문자, 숫자 그런게 아님 )




1. Number.MAX_VALUE
    Number.MIN_VALUE
    Number.NaN -> (Not a Number) -> 숫자가 아닐때
    숫자가 아니면 true
    숫자면 false

2. Number.isNaN() -> 엄격하게 체크 (X 사용지양)
  isNaN() -> 비교적 숫자여부만 체크 (O 사용권장)

3.Number.parseInt() -> parseInt()
  Int -> Integer -> 정수(소수점이 없는 수)(1,2,3,0,-1,-2)

  Float -> 실수 -> 소수점이 있는 수 (0.2,1.4,1.45) 부동소수점

4. Number.parseFloat() -> parseFloat()

5. Number.isInteger()

is -> ~ 인지 아닌지

6. Number.isFinite()-> 유한한 숫자인지 체크

7. Number.toFixed() -> 소수점 자리수 제한 표시 -> 문자로 변환




Boolean
 문자를 -> 논리값을 변환하는 생성자
 문자를 -> true, false

 문자를 논리값으로 변환하는 방법
 1. 생성자
 var result - new Boolean(0); -> false ( X 사용지양- 엄격하게 체크 )

 2. 함수 (Boolean) -> 사용권장
 var result - Boolean(null) -> false
 var result - Boolean("abc") -> true

 false -> 0, ""(빈문자열), null, undefined
 true -> false 조건 이외 모두





Math
수학연산과 관련된 객체

Math.PI

Math.abs 절대값
()소수점기준으로)
Math.ceil 올림
Math.floor 버림
Math.round 반올림

max 여러수중 가장큰수 선택
min 여러수중 가장작은 수 선택
pow 제곱 (a,b) a에서 b를 제곱
random 0 ~ 1 사이의 무작위(난수) 수(소수점)
       난수 -> 무작위 수
sign 음수(-1), 양수(+1),0
aqrt 루트를 씌움




Date
날짜와 시간 관련 객체

  getFullYear() -> 전체연도 -> 2021
  getMonth() -> 현재 월(0~11) 0 - 1월, 1 - 2월 ... 0이 나오면 1월 1이 나오면 2월
  getdate() -> 현재 날짜
  getDay() -> 요일(0~6) 0이면 일요일 1이면 월요일 2면 화요일 6이면 토요일


toString -> 객체의 문자열을 반환
Date객체 -> 시간을 반환


GMT+9
다국어 사이트 만들 때
일본, 중국, 미국 (각 나라별로 시간대 다르다.)

GMT+0 -> 시간을 저장하고
현재시간 + 9시간
시간 UTC(GMT 0) 기준시간대 +, - 해서 (각 나라마다 시간대를) 사용 우리나라는 +9




Array (배열 객체)
자바스크립트는 배열이 객체
배열
var a=1;
var b=2;
데이터를 여러개 담을 수 있는 공간

1. 리터럴 방식
변수에 객체를 대입
  var a = [];(변수에 []를 대입 ) == (new Array();)
  var a= ["apple","melon","orange","banana"];
  // length-> 배열의 개수 / 배열의 개수를 가져오는 속성
  접근 - [대괄호 0부터 시작하는 순서]

  배열에는
  1. 원시데이터 (숫자, 문자, null, undefined, "",true,false)
  2. 객체

2. 생성자 방식
  var a = new Array("데이터1","데이터2");
  var a = new Array("abc");
  a b c
데이터를 여러개 입력 -> 데이터가 들어간다.
숫자 1개만 입력 -> 배열 공간을 지정해서 생성   var a = new Array(3);
-> 속성은 없고 length 3만 나옴


있는 속성에 값을 바꿔서 입력하면 바뀜
a[3]; 없는 속성에 값을 추가도 가능 == a.push
delete a[0]; -> 0번째 속성 삭제

Array.~~~
join 구분값 쉼표(,)를 넣어 구분
reserve 반대로 정렬
sort 정렬 순서를 정의하는 함수.
slice (a,b) a부터 b-1 까지 반환  / (a) a부터 끝까지 / () 처음부터 끝까지
splice 특정위치 삭제 후 추가 / (a,b,c) a자리에 추가 b개수만큼 삭제 c를 추가
concat 이어붙이기
pop 마지막요소를 제거하고 그요소를 반환
push 배열끝에 하나이상의 요소를 추가하고 배열에 새로운 길이를 반환
shift 첫번재 요소를 제거하고 그요소를 반환
unshift 배열의 맨 앞쪽에 추가 , 새로운 배열의 길이를 반환

value    index        array
값     위치(순서)   호출한배열
map 배열의 각각의 요소에 함수를 호출한 결과를 모아 새로운 배열에 반환
filter map이랑 비슷한대 true 인 값만을 반환
forEach 함수를 각각의 배열 요소에 실행





문자 리터럴
`문자`        역따옴표(``) 사용
문자 사이에 줄개행해도 문자로 인식가능

보간(placegolder) 표현법
문자 내에  변수를 추가 -> ${ 변수나 연산 }




open -> 레이어 팝업


setTimeout -> 실행지연 -> clearTimeout -> 지연 삭제
setInterval -> 반복지연실행 -> clearInterval -> 지연 삭제


e.stopPropagation() -> 이벤트 전파 차단
e.preventDefault() -> 태그의 기본동작 중지



중첩함수
- 함수안에 함수를 작성
function outer(a) {
  var b = a * a;
  return inner(b);

  function inner(b) {
    return a+b;
  } //inner 함수는 outer내부에서만 호출이 가능(지역함수)
}

outer(3);
12

- 함수 안에서 함수를 반환(return)
function outer(a) {

  return function(b) {

    return a+b;
  }
}

var a = outer(3); //function(b)
a(10); // function(b)에 b 에 10이라는 인수를 넣음
:13 나옴 

- 함수를 인수로 사용 
function outer(callback) {
  var event = 'callback 넘길변수';
  callback(event); //outer 함수 내부에서 함수실행
}

outer(function(event){

});





메서드 체이닝 
var chain {
  method1 : function {
    console.log('method1 실행');
  },
  method2 : function() {
    console.log('method2 실행');
  },
  method3 : function() {
    console.log('method3 실행');
  },
};

chain.method1();
chain.method2();
chain.method3();



예외 처리
개발시에 특정 부분이 오류가 예상이 될 때
예외처리를 하거나 오류에 대한 후속 조치를 할 때 

try ~ catch,throw 

try {
  throw (던지면)   "오류";
} catch (e) (받는다) { //throw 를 받고 처리 
  
}finally { // throw를 던지면 무조건 실행 
    
}





이벤트를 주려면 -> 대상을 선택해야 한다 (특정 HTML 태그를 선택) 
1. id로 선택하는 방법 (id는 유일값)
<div id = '아이디명'></div> 
document.getElementById('아이디명');


2. class로 선택하는 방법 (복수 선택 가능)
<div class='클래스명'></div>
document.getElementsByClassName('클래스명');

3. 태그이름으로 선택하는 방법(복수로 선택가능)
document.getElementsByTagName('태그명');

4.CSS 선택자 방식으로 선택하는 방법 
document.querySelector('CSS 선택자');
매칭되는 가장 첫번째를 선택 -> 1개만 선택이 된다 

document.querySelectorAll('CSS 선택자'); -> 복수개 선택가능 

































....
