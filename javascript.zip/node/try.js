try {

    var error = true;
    if (error) {
      //  throw new Error("에러 발생"); // 에러 던지고 실행 흐름 중단

        var errorMsg = {
            error : true,
            message : "...오류발생",
        }
        throw errorMsg;
    }

    console.log("에러가 발생하지 않았을때 실행되는 부분");

} catch (e) {
    console.log(e);
    //console.log("오류처리하고있음");
} finally {
    console.log("throw하면 무조건 실행되는 영역");
}