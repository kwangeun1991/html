

//만든사람






const mobileSlide= {
  open: function(){
    $('#layer_dim').removeClass('dn');

    $('.slide').removeClass('on')
              .addClass('on');
  },
  close: function(){
    $('.slide').removeClass('on');

    $('#layer_dim').removeClass('dn')
                  .addClass('dn');
  }
};

$(()=>{
  $('.slide_open').click(function(){
    mobileSlide.open();
  });

  $('.slide_close, #layer_dim').click(function(){
    mobileSlide.close();
  });
});
