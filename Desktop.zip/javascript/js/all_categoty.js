/*

전체메뉴


만든사람



*/


const AllCategory = {
  /*전체메뉴열기*/
  open: function() {
    $('.all_category').removeClass('on')
      .removeClass('fadein')
      .addClass('on');
    setTimeout(function() {
      $('.all_category').addClass('fadein');
    }, 300);

  },
  /*전체메뉴닫기*/
  close: function() {
    $('.all_category').removeClass('fadein');
    setTimeout(function() {
      $('.all_category').removeClass('on');
    }, 1000);
  }
};



$(() => {
  $('#open_all').click(function() {
    if ($('.all_category').hasClass('on')) {
      //열려있으면 닫기
      AllCategory.close();
    } else {
      AllCategory.open();
    }

  });

  $('.navi').mouseleave(function() {
    AllCategory.close();
  });
});
