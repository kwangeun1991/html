const goodsForm = {
  add : function() {
    $html = 
  },
  remove : function() {

  }
};

$(() => {

});
