var chain {
    method1 : function {
      console.log ('method1 실행');
      return this;
    },
    
    method2 : function() {
      console.log ('method2 실행');
      return this;
    },
    
    method3 : function() {
      console.log ('method3 실행');

      return this;
    },
};
  
  chain.method1()
.method2()
.method3();
  