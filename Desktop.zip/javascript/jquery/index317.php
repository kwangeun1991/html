<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!--<script>
      setTimeout(() => {
        location.herf='page.php';
      },3000);
    </script>-->
    <script>
      $(()=>{
        $.ajax({
          url:"page.php",
          type:"get",
          dataType:"html",
          success: function(res){
            $('body').html(res);
          },
          error: function(err){
            console.log(err);
          }
        });
      });
    </script>
  </head>
  <body>

  </body>
</html>
