<?php
header("Content-Type", "application/json; charset=utf-8");
$list = [
  "남은 사람들 위력 겁나서가 아니라 나를 위해 용서하고",
  "美 애틀랜타 마사지숍 3곳서 총기 난 사망자 8명 중 4명 한인 여성",
  "박범계 오늘 한명숙 사건 수사지휘권 발동 전망",
  "김진욱 이성윤 주장 들어볼 필요 있어 면담...특별한 내",
  "구미 3살 여아 친모 검찰 송치…사체유기 미수 추가",
];

echo json_encode($list);
