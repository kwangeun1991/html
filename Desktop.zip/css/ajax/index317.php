<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!--<script>
      setTimeout(() => {
        location.herf='page.php';
      },3000);
    </script>-->
    <script>
          $(()=>{ //ready
            $('.post').click(function(){
              const num = $(this).data('num');
              //const url = `post/${num}.php`; HTML 데이터 변경
              const url = 'post/images.php'; //JSON 데이터 변경

            $.ajax({
              url:url,
              type:"get",
              dataType:"json",
              data: {num:num},
              success: function(res){
                //$('body').html(res);
                const image = `<img src ='${res.imageSrc}'>`;
                $('#text').text(res.text);
                $('#image').html(image);
              },
              error: function(err){
                console.error(err);
              }
                });
              });
            });
    </script>
    <style>
      .form{
        margin-bottom: 10px;
      }
      .post{
        border: 1px solid #000000;
        padding: 5px 20px;
        background-color: red;
        color: #ffffff;
      }
    </style>
  </head>
  <body>
    <div class='form'>
      <span class='post' data-num='1'>글1</span>
      <span class='post' data-num='2'>글2</span>
      <span class='post' data-num='3'>글3</span>
    </div>
    <div id="output">
      <div id="text"></div>
      <div id="image"></div>
    </div>
  </body>
</html>
