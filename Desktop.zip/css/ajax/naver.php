

<!doctype html>                <html lang="ko" data-dark="false"> <head> <meta charset="utf-8"> <title>NAVER</title> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=1190"> <meta name="apple-mobile-web-app-title" content="NAVER"/> <meta name="robots" content="index,nofollow"/> <meta name="description" content="네이버 메인에서 다양한 정보와 유용한 컨텐츠를 만나 보세요"/> <meta property="og:title" content="네이버"> <meta property="og:url" content="https://www.naver.com/"> <meta property="og:image" content="https://s.pstatic.net/static/www/mobile/edit/2016/0705/mobile_212852414260.png"> <meta property="og:description" content="네이버 메인에서 다양한 정보와 유용한 컨텐츠를 만나 보세요"/> <meta name="twitter:card" content="summary"> <meta name="twitter:title" content=""> <meta name="twitter:url" content="https://www.naver.com/"> <meta name="twitter:image" content="https://s.pstatic.net/static/www/mobile/edit/2016/0705/mobile_212852414260.png"> <meta name="twitter:description" content="네이버 메인에서 다양한 정보와 유용한 컨텐츠를 만나 보세요"/>  <link rel="stylesheet" href="https://pm.pstatic.net/dist/css/nmain.20210224.css"> <link rel="stylesheet" href="https://ssl.pstatic.net/sstatic/search/pc/css/sp_autocomplete_201028.css"> <link rel="shortcut icon" type="image/x-icon" href="/favicon.ico?1"/>   <script>document.domain="naver.com",window.nmain=window.nmain||{},window.nmain.supportFlicking=!1;var nsc="navertop.v4",ua=navigator.userAgent;window.nmain.isIE=navigator.appName&&navigator.appName.indexOf("Explorer")>0&&ua.toLocaleLowerCase().indexOf("msie 10.0")<0,document.getElementsByTagName("html")[0].setAttribute("data-useragent",ua),window.nmain.isIE&&(Object.create=function(n){function a(){}return a.prototype=n,new a})</script> <script>var darkmode= false;window.naver_corp_da=window.naver_corp_da||{main:{}},window.naver_corp_da.main=window.naver_corp_da.main||{},window.naver_corp_da.main.darkmode=darkmode</script> <script> window.nmain.gv = {  isLogin: false,
useId: null,   daInfo: {"ANIMAL":{"menu":"ANIMAL","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000161","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_animal_1","tb":"ANIMAL_1","unit":"SU10567","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000162","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_animal_2","tb":"ANIMAL_1","unit":"SU10568","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"BEAUTY":{"menu":"BEAUTY","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000163","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_beauty_1","tb":"BEAUTY_1","unit":"SU10595","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000164","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_beauty_2","tb":"BEAUTY_1","unit":"SU10596","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"BUSINESS":{"menu":"BUSINESS","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000165","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_business_1","tb":"BUSINESS_1","unit":"SU10577","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000166","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_business_2","tb":"BUSINESS_1","unit":"SU10578","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"CARGAME":{"menu":"CARGAME","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000167","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_cargame_1","tb":"CARGAME_1","unit":"SU10587","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000168","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_cargame_2","tb":"CARGAME_1","unit":"SU10588","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"CHINA":{"menu":"CHINA","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000169","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_china_1","tb":"CHINA_1","unit":"SU10591","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000170","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_china_2","tb":"CHINA_1","unit":"SU10592","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"DESIGN":{"menu":"DESIGN","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000171","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_design_1","tb":"DESIGN_1","unit":"SU10569","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000172","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_design_2","tb":"DESIGN_1","unit":"SU10570","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"FARM":{"menu":"FARM","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000173","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_farm_1","tb":"FARM_1","unit":"SU10561","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000174","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_farm_2","tb":"FARM_1","unit":"SU10562","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"FINANCE":{"menu":"FINANCE","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000175","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_finance_1","tb":"FINANCE_1","unit":"SU10563","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000176","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_finance_2","tb":"FINANCE_1","unit":"SU10564","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"ITTECH":{"menu":"ITTECH","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000177","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_ittech_1","tb":"ITTECH_1","unit":"SU10593","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000178","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_ittech_2","tb":"ITTECH_1","unit":"SU10594","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"JOB":{"menu":"JOB","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000179","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_job_1","tb":"JOB_1","unit":"SU10589","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000180","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_job_2","tb":"JOB_1","unit":"SU10590","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"LAW":{"menu":"LAW","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000181","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_law_1","tb":"LAW_1","unit":"SU10573","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000182","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_law_2","tb":"LAW_1","unit":"SU10574","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"LIVING":{"menu":"LIVING","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000183","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_living_1","tb":"LIVING_1","unit":"SU10597","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000184","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_living_2","tb":"LIVING_1","unit":"SU10606","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"LIVINGHOME":{"menu":"LIVINGHOME","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000185","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_livinghome_1","tb":"LIVINGHOME_1","unit":"SU10571","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000186","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_livinghome_2","tb":"LIVINGHOME_1","unit":"SU10572","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"MOMKIDS":{"menu":"MOMKIDS","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000187","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_momkids_1","tb":"MOMKIDS_1","unit":"SU10575","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000188","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_momkids_2","tb":"MOMKIDS_1","unit":"SU10576","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"MOVIE":{"menu":"MOVIE","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000189","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_movie_1","tb":"MOVIE_1","unit":"SU10585","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000190","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_movie_2","tb":"MOVIE_1","unit":"SU10586","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"SCHOOL":{"menu":"SCHOOL","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000191","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_school_1","tb":"SCHOOL_1","unit":"SU10579","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000192","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_school_2","tb":"SCHOOL_1","unit":"SU10580","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"SHOW":{"menu":"SHOW","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000193","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_show_1","tb":"SHOW_1","unit":"SU10565","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000194","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_show_2","tb":"SHOW_1","unit":"SU10566","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"TRAVEL":{"menu":"TRAVEL","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000195","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_travel_1","tb":"TRAVEL_1","unit":"SU10581","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000196","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_travel_2","tb":"TRAVEL_1","unit":"SU10582","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]},"WEDDING":{"menu":"WEDDING","childMenu":"","adType":"singleDom","multiDomAdUrl":"","multiDomUnit":"","infoList":[{"adposId":"1000197","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_wedding_1","tb":"WEDDING_1","unit":"SU10583","calp":"-"},"type":{"position":"abs","positionIndex":4,"subject":"contents"},"dom":null},{"adposId":"1000198","singleDomAdUrl":"https://siape.veta.naver.com/fxshow","param":{"da_dom_id":"p_main_wedding_2","tb":"WEDDING_1","unit":"SU10584","calp":"-"},"type":{"position":"abs","positionIndex":8,"subject":"contents"},"dom":null}]}},
svt: 20210317164942,
}; </script> <script> window.nmain.newsstand = {
rcode: '11260122',
newsCastSubsInfo: '',
newsStandSubsInfo: ''
};
window.etc = {  };
window.svr = "<!--aweb201-->"; </script> <script src="https://ssl.pstatic.net/tveta/libs/assets/js/pc/main/min/pc.veta.core.min.js" defer="defer"></script> <script src="https://ssl.pstatic.net/tveta/libs/assets/js/common/min/probe.min.js" defer="defer"></script>   <script src="https://pm.pstatic.net/dist/js/external.1be451ae.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script> <script src="https://pm.pstatic.net/dist/js/preload.6f271894.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script> <script src="https://pm.pstatic.net/dist/js/polyfill_async.c6f27998.js?o=www" type="text/javascript" crossorigin="anonymous" async></script>  <script src="https://pm.pstatic.net/dist/js/vendors~search.4db2eeeb.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script>   <script src="https://pm.pstatic.net/dist/js/search.828c4644.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script>  <script src="https://pm.pstatic.net/dist/js/vendors~more~nmain~sidebar_notice.cd8eaf3c.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script> <script src="https://pm.pstatic.net/dist/js/vendors~nmain.b342e165.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script> <script src="https://pm.pstatic.net/dist/js/nmain.c42f61b5.js?o=www" type="text/javascript" crossorigin="anonymous" defer="defer"></script> <style>:root{color-scheme:light}#_nx_kbd .setkorhelp a{display:none}</style> </head> <body> <div id="u_skip"> <a href="#newsstand"><span>뉴스스탠드 바로가기</span></a> <a href="#themecast"><span>주제별캐스트 바로가기</span></a> <a href="#timesquare"><span>타임스퀘어 바로가기</span></a> <a href="#shopcast"><span>쇼핑캐스트 바로가기</span></a> <a href="#account"><span>로그인 바로가기</span></a> </div> <div id="wrap"> <style type="text/css">._1syGnXOL{padding-right:18px;font-size:14px;line-height:0;letter-spacing:-.25px;color:#000}._1syGnXOL span,._1syGnXOL strong{line-height:49px}._1syGnXOL:before{display:inline-block;content:"";vertical-align:top;background-image:url(https://static-whale.pstatic.net/main/sprite-20201210@2x.png);background-repeat:no-repeat;background-size:114px 107px;width:18px;height:18px;margin:16px 8px 0 0;background-position:0 -89px}[data-useragent*="MSIE 8"] ._1syGnXOL:before{background-image:url(https://static-whale.pstatic.net/main/sprite-20201210.png)}._1syGnXOL._3dsvmZg2:before{background-position:-68px -63px}._1syGnXOL._1NBFx1WK:before{width:20px;height:20px;margin:15px 8px 0 0;background-position:-26px -85px}._1syGnXOL._2mcQEKCd:before{width:22px;height:22px;margin:14px 7px 0 0;background-position:-26px -63px}._1syGnXOL._18YOHi7v{color:#fff}._1syGnXOL._3di88A4c{padding-right:12px;font-size:17px}._1syGnXOL._3di88A4c:before{content:none}._1syGnXOL._3jtl_dKE{font-size:16px}._1syGnXOL ._19K4X1CD{text-decoration:underline}._2aeXMlrb{display:inline-block;position:relative;font-size:12px;height:49px;width:78px;text-decoration:none;color:#fff;font-weight:700;letter-spacing:-.5px;vertical-align:top}._2aeXMlrb span{text-align:center;margin:9px 0;height:31px;display:block;line-height:31px;border-radius:15px}._2aeXMlrb span:before{display:inline-block;content:"";vertical-align:top;background-image:url(https://static-whale.pstatic.net/main/sprite-20201210@2x.png);background-repeat:no-repeat;background-size:114px 107px}[data-useragent*="MSIE 8"] ._2aeXMlrb span:before{background-image:url(https://static-whale.pstatic.net/main/sprite-20201210.png)}._2aeXMlrb.BMgpjddw{font-size:11px;width:94px}._2aeXMlrb.BMgpjddw span:before{margin:9px 3px 0 0;width:17px;height:13px;background-position:-98px -30px}._3h-N8T9V{position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0)}._1KncATpM{display:inline-block;content:"";vertical-align:top;background-image:url(https://static-whale.pstatic.net/main/sprite-20201210@2x.png);background-repeat:no-repeat;background-size:114px 107px;margin-top:14px;float:left;width:98px;height:21px;background-position:0 -21px}[data-useragent*="MSIE 8"] ._1KncATpM{background-image:url(https://static-whale.pstatic.net/main/sprite-20201210.png)}._1KncATpM._2v3uxv2x{background-position:0 0}._1KncATpM._1yl_Ow6o{background-position:0 -42px}._20PYt6lT{font-size:11px;height:49px;cursor:pointer;position:absolute;top:0;right:0;color:#666;opacity:.7}._20PYt6lT:after{width:15px;height:15px;margin-left:4px;background-position:-98px 0;display:inline-block;content:"";vertical-align:top;background-image:url(https://static-whale.pstatic.net/main/sprite-20201210@2x.png);background-repeat:no-repeat;background-size:114px 107px}[data-useragent*="MSIE 8"] ._20PYt6lT:after{background-image:url(https://static-whale.pstatic.net/main/sprite-20201210.png)}._20PYt6lT._39oMCV2N:after{background-position:-98px -15px}._20PYt6lT._3wm5EzmJ{color:#fff}._20PYt6lT._3wm5EzmJ:after{background-position:-48px -83px}._1hiMWemA{height:49px}._1hiMWemA .tY_u8r23{position:relative;width:1130px;margin:0 auto}._1hiMWemA .tY_u8r23 a{text-decoration:none}._1hiMWemA._23U_6TM_{position:relative}._1hiMWemA._23U_6TM_:after{position:absolute;z-index:1;content:"";display:block;width:100%;height:1px;bottom:0;background-color:rgba(0,0,0,.05)}</style>                  <div id="NM_TOP_BANNER" data-clk-prefix="top" class="_1hiMWemA" style="background-color: #f3f1ff;">
<div class="tY_u8r23">
<a class="_3h-N8T9V" href='https://whale.naver.com/details/darkmode?=main&wpid=RydDy7'
data-clk="dropbanner1a"></a>
<i class="_1KncATpM"><span class="blind">NAVER whale</span></i>
<img src="https://static-whale.pstatic.net/main/img_darkmode@2x.png" width="303" height="49" alt=""
style="padding-left: 48px;"/>
<span class="_1syGnXOL _3di88A4c" data-clk="dropbanner1a" style="padding-right: 10px; padding-left: 8px;"><span>여러분의
눈은 소중하니까, </span><strong>지금 바로 다크 모드를 켜세요!</strong></span>
<a href='https://installer-whale.pstatic.net/downloads/banner/RydDy7/WhaleSetup.exe' class="_2aeXMlrb" id="NM_whale_download_btn"
data-clk="dropdownload1a"><span style="background-color: #7c56d5;">다운로드</span></a>
<button type="button" data-ui-cookie-exp-days="3" data-ui-cookie-key="NM_TOP_PROMOTION" data-ui-cookie-value="1"
data-ui-hide-target="#NM_TOP_BANNER" data-clk="dropclose1a" class="_20PYt6lT _39oMCV2N"
style="display: none;">
3일 동안 보지 않기
</button>
</div>
</div>
  <div id="header" role="banner">








<div class="special_bg">
<div class="group_flex">
<div class="logo_area">
<h1 class="logo_default">
<a href="/" class="logo_naver" data-clk="top.logo"
><span class="blind">네이버</span></a
>
</h1>
</div>
<div class="service_area">
<a id="NM_set_home_btn" href="https://help.naver.com/support/welcomePage/guide.help" class="link_set" data-clk="top.mkhome">네이버를 시작페이지로</a>
<i class="sa_bar"></i>
<a href="https://jr.naver.com" class="link_jrnaver" data-clk="top.jrnaver"><i class="ico_jrnaver"></i><span class="blind">쥬니어네이버</span></a>
<a href="https://happybean.naver.com" class="link_happybin" data-clk="top.happybean"><i class="ico_happybin"></i><span class="blind">해피빈</span></a>
</div>

<div id="search" class="search_area" data-clk-prefix="sch">
<form id="sform" name="sform" action="https://search.naver.com/search.naver" method="get" role="search">
<fieldset>
<legend class="blind">검색</legend>
<select id="where" name="where" title="검색 범위 선택" class="blind">
<option value="nexearch" selected="selected">통합검색</option><option value="post">블로그</option><option value="cafeblog">카페</option><option value="cafe">- 카페명</option><option value="article">- 카페글</option><option value="kin">지식iN</option><option value="news">뉴스</option><option value="web">사이트</option><option value="category">- 카테고리</option><option value="site">- 사이트</option><option value="movie">영화</option><option value="webkr">웹문서</option><option value="dic">사전</option><option value="100">- 백과사전</option><option value="endic">- 영어사전</option><option value="eedic">- 영영사전</option><option value="krdic">- 국어사전</option><option value="jpdic">- 일본어사전</option><option value="hanja">- 한자사전</option><option value="terms">- 용어사전</option><option value="book">책</option><option value="music">음악</option><option value="doc">전문자료</option><option value="shop">쇼핑</option><option value="local">지역</option><option value="video">동영상</option><option value="image">이미지</option><option value="mypc">내PC</option><optgroup label="스마트 파인더"><option value="movie">영화</option><option value="auto">자동차</option><option value="game">게임</option><option value="health">건강</option><option value="people">인물</option></optgroup><optgroup label="네이버 랩"><option>긍정부정검색</option></optgroup>
</select>
<input type="hidden" id="sm" name="sm" value="top_hty" />
<input type="hidden" id="fbm" name="fbm" value="0" />
<input type="hidden" id="acr" name="acr" value="" disabled="disabled" />
<input type="hidden" id="acq" name="acq" value="" disabled="disabled" />
<input type="hidden" id="qdt" name="qdt" value="" disabled="disabled" />
<input type="hidden" id="ie" name="ie" value="utf8" />
<input type="hidden" id="acir" name="acir" value="" disabled="disabled" />
<input type="hidden" id="os" name="os" value="" disabled="disabled" />
<input type="hidden" id="bid" name="bid" value="" disabled="disabled" />
<input type="hidden" id="pkid" name="pkid" value="" disabled="disabled" />
<input type="hidden" id="eid" name="eid" value="" disabled="disabled" />
<input type="hidden" id="mra" name="mra" value="" disabled="disabled" />



<div class="green_window" style=''>
<!-- [AU] data-atcmp-element 에 해당하는 attribute를 추가해주세요. -->
<input id="query" name="query" type="text" title="검색어 입력" maxlength="255" class="input_text" tabindex="1" accesskey="s" style="ime-mode:active;" autocomplete="off"  placeholder="검색어를 입력해 주세요." onclick="document.getElementById('fbm').value=1;" value="" data-atcmp-element>
</div>
<button id="search_btn" type="submit" title="검색" tabindex="3" class="btn_submit" onclick="window.nclick(this,'sch.action','','',event);" style=''>
<span class="blind">검색</span>
<span class="ico_search_submit"></span>
</button>
</fieldset>
</form>
<!-- 한글입력기 -->
<a href="#" id="ke_kbd_btn" role="button" class="btn_keyboard" onclick="return false;"><span class="blind">한글 입력기</span><span class="ico_keyboard"></span></a>
<div id="_nx_kbd" style="display:none;"></div>
<div class="autocomplete">
<!-- 자동완성 열린 경우 fold 클래스 추가, 딤드인 경우 dim 추가 -->
<a href="#" role="button" id="nautocomplete" tabindex="2" class="btn_arw _btn_arw fold" aria-pressed="false" data-atcmp-element><span class="blind">자동완성 레이어</span><span class="ico_arr"></span></a>
</div>
<!-- 자동완성레이어 -->
<div id="autoFrame" class="reatcmp" style="display: none;">
<!-- [AU] data-atcmp-element attribute를 추가해주세요. -->
<div class="ly_atcmp" data-atcmp-element>
<div class="api_atcmp_wrap">
<!-- 최근검색어 -->
<!-- [AU] _recent_layer 클래스를 추가해주세요. -->
<div class="atcmp_fixer _recent_layer" style="display:none;">
<!-- [AU] _recent_header 클래스를 추가해주세요. -->
<div class="atcmp_header _recent_header">
<strong class="tit">최근검색어</strong>
<div class="option">
<!-- [AU] _delAll 클래스를 추가해주세요. -->
<a role="button" href="#" class="item _delAll" aria-pressed="false">전체삭제</a>
</div>
</div>
<div class="atcmp_container">
<!-- [AU] _recent 클래스를 추가해주세요. -->
<ul class="kwd_lst _recent">
<!-- 최근검색어 템플릿 -->
<!-- [AU] _item 클래스를 추가해주세요. -->
<!-- [AU] data-template-type="history" data-keyword="@in_txt@" attribute를 추가해주세요. -->
<li class="item _item" data-rank="@rank@" data-template-type="history" data-keyword="@in_txt@">
<a href="#" class="kwd">
<span class="fix"><span class="common_ico_kwd"><i class="imsc ico_search"></i></span><span>@txt@</span></span>
</a>
<span class="etc">
<em class="date">@date@.</em>
<!-- [AU] _del 클래스를 추가해주세요. -->
<a href="#" role="button" class="bt_item _del" aria-pressed="false"><i class="imsc ico_del">삭제</i></a>
</span>
</li>
</ul>
<!-- [D] 검색어 저장 꺼진 경우 atcmp_fixer에 type_off 추가 -->
<!-- [AU] _offMsg 클래스를 추가해주세요. -->
<div class="kwd_info kwd_off _offMsg" style="display: none;">검색어 저장 기능이 꺼져 있습니다.<br><span class="kwd_dsc">설정이 초기화 된다면 <a href="https://help.naver.com/support/alias/search/word/word_29.naver" class="kwd_help" data-clk="sly.help" target="_blank">도움말</a>을 확인해주세요.</span></div>
<!-- [D] 검색어 내역 없는 경우 atcmp_fixer에 type_off 추가 -->
<!-- [AU] _recentNone 클래스를 추가해주세요. -->
<div class="kwd_info kwd_none _recentNone" style="display: none;">최근 검색어 내역이 없습니다.<br><span class="kwd_dsc">설정이 초기화 된다면 <a href="https://help.naver.com/support/alias/search/word/word_29.naver" class="kwd_help" data-clk="sly.help" target="_blank">도움말</a>을 확인해주세요.</span></div>
</div>
<div class="atcmp_footer">
<span class="side_opt_area">
<span class="opt_item"><a href="https://help.naver.com/support/service/main.help?serviceNo=605&amp;categoryNo=1991" data-clk="sly.help" target="_blank">도움말</a></span>
</span>
<span class="rside_opt_area">
<span class="opt_item">
<!-- [AU] _keywordOnOff 클래스를 추가해주세요. -->
<a href="#" class="close _keywordOnOff">자동저장 끄기</a>
</span>
</span>
</div>
</div>
<!-- 자동완성 -->
<!-- [AU] _atcmp_layer 클래스를 추가해주세요. -->
<div class="atcmp_fixer _atcmp_layer" style="display:none;">
<!-- [AU] _words 클래스를 추가해주세요. -->
<div class="atcmp_container _words">
<!-- 정답형 템플릿 : 로또당첨번호 -->
<!-- [AU] _answer 클래스를 추가해주세요. -->
<!-- [AU] data-template-type="answer_3" data-code="@code@" data-keyword="@1@" attribute를 추가해주세요. -->
<div class="atcmp_correct type_lotto _answer" data-template-type="answer_3" data-code="@code@" data-keyword="@1@">
<a href="#" class="link_item">
<span class="common_ico_kwd"><i class="imsc ico_search"></i></span>
<div class="dsc_area">
<span class="tit">@5@회차 당첨번호</span>
<span class="dsc">
<span class="item">추첨 @13@.</span><span class="item">지급기한 1년</span>
</span>
</div>
<span class="etc_area">
<span class="etc lotto">
<em class="n@6@">@6@</em><em class="n@7@">@7@</em><em class="n@8@">@8@</em><em class="n@9@">@9@</em><em class="n@10@">@10@</em><em class="n@11@">@11@</em><em class="imsc_bf bonus n@12@">@12@</em>
</span>
</span>
</a>
</div>
<!-- 정답형 템플릿 : 환율 -->
<!-- [AU] _answer 클래스를 추가해주세요. -->
<!-- [AU] data-template-type="answer_9" data-code="@code@" data-keyword="@1@" attribute를 추가해주세요. -->
<div class="atcmp_correct type_exchange _answer" data-template-type="answer_9" data-code="@code@" data-keyword="@1@">
<!-- [D] 상승 up, 하락 down 추가 -->
<a href="#" class="link_item @11@">
<!-- [D] 국가별 class 가나다순
ZAR 남아프리카 공화국
NPR 네팔
NOK 노르웨이
NZD 뉴질랜드
TWD 대만
DKK 덴마크
RUB 러시아
MOP 마카오
MYR 말레이시아
MXN 멕시코
MNT 몽골
USD 미국
BHD 바레인
BDT 방글라데시
VND 베트남
BRL 브라질
SAR 사우디아라비아
SEK 스웨덴
CHF 스위스
SGD 싱가포르
AED 아랍에미리트
GBP 영국
EUR 유럽연합
ILS 이스라엘
EGP 이집트
INR 인도
IDR 인도네시아
JPY 일본
CNY 중국
CZK 체코
CLP 칠레
KZT 카자흐스탄
QAR 카타르
CAD 캐나다
KWD 쿠웨이트
THB 태국
TRY 터키
PKR 파키스탄
PLN 폴란드
PHP 필리핀
HUF 헝가리
AUD 호주
HKD 홍콩
-->
<span class="common_ico_kwd"><i class="imsc ico @12@">@14@</i></span>
<div class="dsc_area">
<span class="tit">@txt@<span class="sub">@currency@</span></span>
<span class="dsc">
<span class="item"><i class="imsc ico_arr"></i>@8@(@9@%)</span>
</span>
</div>
<span class="etc_area">
<span class="etc"><em class="num">@6@</em>원</span>
</span>
</a>
</div>
<!-- 정답형 템플릿 : 날씨(국내11, 해외12) -->
<!-- [AU] _answer 클래스를 추가해주세요. -->
<!-- [AU] data-template-type="answer_11" data-code="@code@" data-keyword="@1@" attribute를 추가해주세요. -->
<div class="atcmp_correct type_weather _answer" data-template-type="answer_11" data-code="@code@" data-keyword="@1@">
<!-- [D] 상승 up, 하락 down 추가 -->
<a href="#" class="link_item @12@">
<span class="common_ico_kwd"><i class="imsc ico_search"></i></span>
<div class="dsc_area">
<span class="tit">@txt@</span>
<span class="dsc">
<span class="item">@7@, @message@</span>
</span>
</div>
<span class="etc_area">
<span class="etc">
<!-- [D] 날씨별 class
ico1 맑음(낮)
ico2 맑음(밤)
ico3 구름조금(낮)
ico4 구름조금(밤)
ico5 구름많음(낮)
ico6 구름많음(밤)
ico7 흐림
ico8 약한비
ico9 비
ico10 강한비
ico11 약한눈
ico12 눈
ico13 강한눈
ico14 진눈깨비
ico15 소나기
ico16 안개
ico17 소낙눈
ico18 번개뇌우
ico19 우박
ico20 황사
ico21 비또는눈
ico22 가끔비
ico23 가끔눈
ico24 가끔비또는눈
ico25 흐린후갬
ico26 뇌우후갬
ico27 비후갬
ico28 눈후갬
ico29 흐려져비
ico30 흐려져눈
-->
<span class="ico_weather"><i class="imsc ico ico@iconNo@">@7@</i></span>
<em class="degree">@8@<sup class="celsius">°</sup></em>
</span>
</span>
</a>
</div>
<!-- 정답형 템플릿 : 사이트 바로가기 -->
<!-- [AU] _answer 클래스를 추가해주세요. -->
<!-- [AU] data-template-type="answer_17" data-code="@code@" data-keyword="@1@" attribute를 추가해주세요. -->
<div class="atcmp_correct type_site _answer" data-template-type="answer_17" data-code="@code@" data-keyword="@1@">
<a href="@5@" class="link_item" target="_blank">
<span class="common_ico_kwd"><i class="imsc ico_url"></i></span>
<div class="dsc_area">
<span class="tit">@txt@</span>
<span class="dsc">
<span class="item">@5@</span>
</span>
</div>
<span class="etc_area">
<span class="etc">바로가기</span>
</span>
</a>
</div>
<!-- [AU] _kwd_list 클래스를 추가해주세요. -->
<ul class="kwd_lst _kwd_list">
<!-- [AU] 자동완성 검색어 템플릿 -->
<!-- [AU] _item 클래스를 추가해주세요. -->
<!-- [AU] data-rank="@rank@" data-template-type="suggestion" data-keyword="@in_txt@" attribute를 추가해주세요. -->
<li class="item _item" data-rank="@rank@" data-template-type="suggestion" data-keyword="@in_txt@">
<a href="#" class="kwd">
<span class="fix"><span class="common_ico_kwd"><i class="imsc ico_search"></i></span>@txt@</span>
</a>
<span class="etc">
<a href="#" role="button" class="bt_item _add" aria-pressed="false"><i class="imsc ico_insert">추가</i></a>
</span>
</li>
<!-- [AU] 최근검색어 템플릿 -->
<!-- [AU] _item 클래스를 추가해주세요. -->
<!-- [AU] data-rank="@rank@" data-template-type="history" data-keyword="@in_txt@" attribute를 추가해주세요. -->
<li class="item has_correct _item" data-rank="@rank@" data-template-type="history" data-keyword="@in_txt@">
<a href="#" class="kwd">
<span class="fix"><span class="common_ico_kwd"><i class="imsc ico_search"></i></span>@txt@</span>
</a>
<span class="etc">
<!-- 최근검색어 있으면 날짜 표시 -->
<em class="date">@date@.</em>
<a href="#" role="button" class="bt_item _add" aria-pressed="false"><i class="imsc ico_insert">추가</i></a>
</span>
</li>
</ul>
<!-- [AU] 문맥검색 템플릿 -->
<!-- [AU] _item 클래스를 추가해주세요. -->
<!-- [AU] data-rank="@rank@" data-template-type="intend" data-keyword="@transQuery@" attribute를 추가해주세요. -->
<li class="item has_correct _item" data-rank="@rank@" data-intend-rank="@intendRank@" data-template-type="intend" data-keyword="@transQuery@">
<a href="#" class="kwd">
<span class="fix"><span class="common_ico_kwd"><i class="imsc ico_search"></i></span>@query@ <span class="context">@intend@</span></span>
</a>
<span class="etc">
<a href="#" role="button" class="bt_item _add" aria-pressed="false"><i class="imsc ico_insert">추가</i></a>
</span>
</li>
<!-- [D] 선거안내문구 -->
<!-- [AU] _alert 클래스를 추가해주세요. -->
<div class="atcmp_alert _alert">
<div class="dsc_election">
<i class="imsc ico_election"></i>
<p class="dsc">선거 후보자에 대해 자동완성을 제공하지 않습니다.
<span class="dsc_inner">기간 : 4월 2일 0시 ~ 4월 15일 18시까지</span>
<a href="#" class="link">자세히보기</a>
</p>
</div>
</div>
<!-- [AU] _plus 클래스를 추가해주세요. -->
<div class="atcmp_plus _plus">
<div class="dsc_plus">
<a href="https://help.naver.com/support/contents/contents.nhn?serviceNo=606&categoryNo=16658" class="link_dsc" data-clk="sug.cxhelp" target="_blank">관심사를 반영한 컨텍스트 자동완성<i class="imsc ico_help">도움말</i></a>
</div>
<div class="switch">
<!-- [D] 선택시 aria-pressed="ture/false" -->
<!-- [AU] _plus_btn 클래스를 추가해주세요. -->
<a role="button" href="#" class="bt_switch active _plus_btn" aria-pressed="false"><i class="imsc ico_option">컨텍스트 자동완성</i></a>
</div>
<!-- [AU] _plus_layer 클래스를 추가해주세요. -->
<div class="layer_plus _plus_layer">
<strong class="tit">컨텍스트 자동완성</strong>
<!-- [AU] _plus_layer_isloggedin 클래스를 추가해주세요. -->
<!-- [AU] style="display:none" 추가해주세요. -->
<div class="_plus_layer_isloggedin" style="display:none">
<p class="dsc">ON/OFF 설정은<br>해당기기(브라우저)에 저장됩니다.</p>
<div class="btn_area">
<a href="https://help.naver.com/support/contents/contents.help?serviceNo=606&categoryNo=16659" class="btn btn_view" data-clk="sug.cxlink" target="_blank">자세히</a>
</div>
</div>
<!-- [AU] _plus_layer_isnotloggedin 클래스를 추가해주세요. -->
<!-- [AU] style="display:none" 추가해주세요. -->
<div class="_plus_layer_isnotloggedin" style="display:none">
<p class="dsc"><em class="txt">동일한 시간대/연령/남녀별</em> 사용자 그룹의<br>관심사에 맞춰 자동완성을 제공합니다.</p>
<div class="btn_area">
<a href="https://nid.naver.com/nidlogin.login" class="btn btn_login" data-clk="sug.cxlogin">로그인</a>
<a href="https://help.naver.com/support/alias/search/word/word_16.naver" class="btn btn_view" data-clk="sug.cxlink" target="_blank">자세히</a>
</div>
</div>
<!-- [AU] _plus_layer_close 클래스를 추가해주세요. -->
<a href="#" role="button" class="btn_close _plus_layer_close"><i class="imsc ico_close">컨텍스트 자동완성 레이어 닫기</i></a>
</div>
</div>
</div>
<div class="atcmp_footer">
<span class="side_opt_area">
<span class="opt_item"><a href="https://help.naver.com/support/service/main.help?serviceNo=605&categoryNo=1987" data-clk="sug.help" target="_blank">도움말</a></span>
<span class="opt_item"><a href="https://help.naver.com/support/contents/contents.help?serviceNo=605&categoryNo=18215" class="report" data-clk="sug.report" target="_blank">신고</a></span>
</span>
<span class="rside_opt_area">
<span class="opt_item">
<!-- [AU] _suggestOnOff 클래스를 추가해주세요. -->
<a href="#" class="close _suggestOnOff">자동완성 끄기</a>
</span>
</span>
</div>
</div>
</div>
</div>
</div>
</div>

</div>
</div>

<!--EMPTY-->
<div id="gnb">
<div id="NM_FAVORITE" class="gnb_inner">
<div class="group_nav">
<ul class="list_nav type_fix">
<li class="nav_item">
<a href="https://mail.naver.com/" class="nav" data-clk="svc.mail"><i class="ico_mail"></i>메일</a>
</li>
<li class="nav_item"><a href="https://section.cafe.naver.com/" class="nav" data-clk="svc.cafe">카페</a></li>
<li class="nav_item"><a href="https://section.blog.naver.com/" class="nav" data-clk="svc.blog">블로그</a></li>
<li class="nav_item"><a href="https://kin.naver.com/" class="nav" data-clk="svc.kin">지식iN</a></li>
<li class="nav_item"><a href="https://shopping.naver.com/" class="nav" data-clk="svc.shopping">쇼핑</a></li>
<li class="nav_item"><a href="https://order.pay.naver.com/home" class="nav" data-clk="svc.pay">Pay</a></li>
<li class="nav_item">
<a href="https://tv.naver.com/" class="nav" data-clk="svc.tvcast"><i class="ico_tv"></i>TV</a>
</li>
</ul>
<ul
class="list_nav NM_FAVORITE_LIST"
>
<li class="nav_item"><a href="https://dict.naver.com/" class="nav" data-clk="svc.dic">사전</a></li>
<li class="nav_item"><a href="https://news.naver.com/" class="nav" data-clk="svc.news">뉴스</a></li>
<li class="nav_item"><a href="https://finance.naver.com/" class="nav" data-clk="svc.stock">증권</a></li>
<li class="nav_item"><a href="https://land.naver.com/" class="nav" data-clk="svc.land">부동산</a></li>
<li class="nav_item"><a href="https://map.naver.com/" class="nav" data-clk="svc.map">지도</a></li>
<li class="nav_item"><a href="https://movie.naver.com/" class="nav" data-clk="svc.movie">영화</a></li>
<li class="nav_item"><a href="https://vibe.naver.com/" class="nav" data-clk="svc.vibe">VIBE</a>
<li class="nav_item"><a href="https://book.naver.com/" class="nav" data-clk="svc.book">책</a></li>
<li class="nav_item"><a href="https://comic.naver.com/" class="nav" data-clk="svc.webtoon">웹툰</a></li>

</ul>
<ul class="list_nav type_empty" style="display: none;"></ul>
<a href="#" role="button" class="btn_more" data-clk="svc.more">더보기</a>
<div class="ly_btn_area">
<a href="more.html" class="btn NM_FAVORITE_ALL" data-clk="map.svcmore">서비스 전체보기</a>
<a href="#" role="button" class="btn btn_set" data-clk="map.edit">메뉴설정</a>
<a href="#" role="button" class="btn btn_reset" data-clk="edt.reset">초기화</a>
<a href="#" role="button" class="btn btn_save" data-clk="edt.save">저장</a>
</div>
</div>
<div id="NM_WEATHER" class="group_weather">
<div>
<a data-clk="squ.weat" href="https://weather.naver.com/today/11260122" class="weather_area ico_w01">
<div class="current_box">
<strong class="current" aria-label="현재기온">13.7°</strong><strong class="state">맑음</strong>
</div>
<div class="degree_box">
<span class="min" aria-label="최저기온">2.0°</span><span class="max" aria-label="최고기온">12.0°</span>
</div>
<span class="location">청라동</span>
</a>
</div>
<div>
<a data-clk="squ.dust" href="https://weather.naver.com/today/11260122" class="air_area">
<ul class="list_air">
<li class="air_item">미세<strong class="state state_bad">나쁨</strong></li>
<li class="air_item">초미세<strong class="state state_normal">보통</strong></li>
</ul>
<span class="location">청라동</span>
</a>
</div>

</div>
</div>
<div class="ly_service">
<div class="group_service NM_FAVORITE_ALL_LY"></div>
<div class="group_service NM_FAVORITE_EDIT_LY" style="display: none;"></div>
</div>
</div>
</div>
 <div id="container" role="main"> <div style="position:relative;width:1130px;margin:0 auto;z-index:11"> <div id="da_top"></div> <div id="da_expwide"></div> </div> <div id="NM_INT_LEFT" class="column_left">  <div id="veta_top"> <iframe id="da_iframe_time" name="da_iframe_time" data-iframe-src="https://siape.veta.naver.com/fxshow?su=SU10599&amp;nrefreshx=0" data-veta-preview="main_time" title="광고" width="750" height="135" marginheight="0" marginwidth="0" scrolling="no" frameborder="0"> </iframe> <span class="veta_bd_t"></span> <span class="veta_bd_b"></span> <span class="veta_bd_l"></span> <span class="veta_bd_r"></span> </div> <div id="newsstand" class="sc_newscast"> <h2 class="blind">뉴스스탠드</h2> <div id="NM_NEWSSTAND_HEADER" class="group_issue" data-clk-prefix="ncy"> <div class="issue_area"> <a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y" class="link_media" data-clk="newsflash">연합뉴스</a> <div id="yna_rolling" class="list_issue"> <div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266492" class="issue" data-clk="quickarticle"><strong>[긴급] </strong>박범계 "대검 부장회의서 '한명숙 사건' 심의" 지시</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266526" class="issue" data-clk="quickarticle">정부 "투기의심자 농지 강제처분…보상 등 추가이익 차단"</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266533" class="issue" data-clk="quickarticle">[2보] 미 국방장관 "중국·북한 위협으로 한미동맹 어느때보다 중요"</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266394" class="issue" data-clk="quickarticle">"혈전 발견된 사망자, 백신과 무관…사인은 폐렴-심근경색 추정"</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266172" class="issue" data-clk="quickarticle">애틀랜타 연쇄총격에 한인여성 4명 사망…증오범죄 가능성 수사</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266029" class="issue" data-clk="quickarticle">단일화 장외설전…김종인·안철수 두고 "네가 X맨" 공방</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266314" class="issue" data-clk="quickarticle">추미애 "쓸모 있다면 나설 수 있지 아무 때나 나선다고 되겠나"</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012265615" class="issue" data-clk="quickarticle">박원순 사건 피해자 "피해사실 관련 소모적 논쟁 멈추길"</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012265884" class="issue" data-clk="quickarticle">민간인 쐈던 5·18 계엄군, 유족 찾아 무릎꿇고 사과…첫 사례</a></div>
<div><a href="http://news.naver.com/main/list.nhn?mode=LPOD&mid=sec&sid1=001&sid2=140&oid=001&isYeonhapFlash=Y&aid=0012266193" class="issue" data-clk="quickarticle">정인이 부검의 "췌장 절단될 정도 손상…폭행 있어야 가능"</a></div> </div> </div> <div class="direct_area"> <a href="http://news.naver.com/" class="link_news" data-clk="newshome">네이버뉴스</a>
<a href="http://entertain.naver.com/home" class="link_direct" data-clk="entertainment">연예</a>
<a href="http://sports.news.naver.com/" class="link_direct" data-clk="sports">스포츠</a>
<a href="http://news.naver.com/main/main.nhn?mode=LSD&mid=shm&sid1=101" class="link_direct" data-clk="economy">경제</a> </div> </div>        <div id="NM_NEWSSTAND_TITLE" class="group_title" data-clk-prefix="nsd"> <a href="http://newsstand.naver.com/" class="link_newsstand" data-clk="title" target="_blank">뉴스스탠드</a> <div id="NM_NEWSSTAND_data_buttons" class="sort_area">  <a href="#" role="button" data-type="my" data-clk="my" class="btn_sort">구독한 언론사</a> <a href="#" role="button" data-type="all" data-clk="all" class="btn_sort sort_on">전체언론사</a>  </div> <div id="NM_NEWSSTAND_view_buttons" class="set_area">  <a href="#" role="button" data-type="list" data-clk="articleview" class="btn_set"> <i class="ico_list"><span class="blind">리스트형</span></i></a> <a href="#" role="button" data-type="thumb" data-clk="pressview" class="btn_set set_on"> <i class="ico_tile"><span class="blind">썸네일형</span></i></a>  <a href="http://newsstand.naver.com/config.html" class="btn_set" data-clk="set" target="_blank"> <i class="ico_set"><span class="blind">설정</span></i></a> </div> </div> <div id="NM_NEWSSTAND_VIEW_CONTAINER" style="position:relative"> <div id="NM_NEWSSTAND_DEFAULT_LIST" class="group_news" style="display:none" data-clk-prefix="nsd_all"> <a href="#" role="button" class="pm_btn_prev_l _NM_NEWSSTAND_LIST_prev_btn" data-clk-custom="prev"><i class="ico_btn"><span class="blind">이전</span></i></a> <a href="#" role="button" class="pm_btn_next_l _NM_NEWSSTAND_LIST_next_btn" data-clk-custom="next"><i class="ico_btn"><span class="blind">다음</span></i></a> <div class="list_view"> <div class="option_area"> <div class="list_option_wrap"> <ul class="list_option"> <li class="option_item" data-cateid="ct2"><a href="#" class="option" data-clk="daei">종합/경제</a></li> <li class="option_item" data-cateid="ct3"><a href="#" class="option" data-clk="dtvcom">방송/통신</a></li> <li class="option_item" data-cateid="ct4"><a href="#" class="option" data-clk="dit">IT</a></li> <li class="option_item" data-cateid="ct5"><a href="#" class="option" data-clk="deng">영자지</a></li> <li class="option_item" data-cateid="ct6"><a href="#" class="option" data-clk="dsporent">스포츠/연예</a></li> <li class="option_item" data-cateid="ct7"><a href="#" class="option" data-clk="dmagtec">매거진/전문지</a></li> <li class="option_item" data-cateid="ct8"><a href="#" class="option" data-clk="dloc">지역</a></li> </ul> </div> </div> <div class="_NM_NEWSSTAND_ARTICLE_CONTAINER" data-clk-sub="*a"></div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_invalid" style="display:none" data-clk-sub="*a"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg">해당 언론사 사정으로 접근이 일시 제한됩니다.</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE">확인</a> </div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_undescribe_confirm" style="display:none" data-clk-sub="*a"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE" data-clk="usclose"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg"><strong class="NM_NEWSSTAND_POPUP_PNAME"></strong>을(를)<br>구독해지 하시겠습니까?</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CONFIRM" data-clk="usdone">확인</a> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE" data-clk="uscancel">취소</a> </div> </div> <div class="ly_toast NM_NEWSSTAND_TOAST" style="display:none"> <p class="toast_msg">구독한 언론사에 추가되었습니다.</p> </div> </div>   <div id="NM_NEWSSTAND_DEFAULT_THUMB" class="group_news" style="display:block" data-clk-prefix="nsd_all"> <a href="#" role="button" class="pm_btn_prev_l _NM_UI_PAGE_PREV" data-clk-custom="prev"><i class="ico_btn"><span class="blind">이전</span></i></a> <a href="#" role="button" class="pm_btn_next_l _NM_UI_PAGE_NEXT" data-clk-custom="next"><i class="ico_btn"><span class="blind">다음</span></i></a> <div class="_NM_UI_PAGE_CONTAINER" style="height:100%;overflow:hidden" data-clk-sub="*p">   <div style="width: 750px; float: left;">
<div class="tile_view">
<div class="frame_area">
<i class="line to_right1"></i>
<i class="line to_right2"></i>
<i class="line to_right3"></i>
<i class="line to_bottom1"></i>
<i class="line to_bottom2"></i>
<i class="line to_bottom3"></i>
<i class="line to_bottom4"></i>
<i class="line to_bottom5"></i>
</div>
<div class="thumb_area">
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="018"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/018.png"
height="20"
alt="이데일리"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="018"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="018"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=018"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="018"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="025"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/025.png"
height="20"
alt="중앙일보"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="025"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="025"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=025"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="025"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="422"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/422.png"
height="20"
alt="연합뉴스TV"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="422"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="422"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=422"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="422"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="293"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/293.png"
height="20"
alt="블로터"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="293"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="293"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=293"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="293"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="092"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/092.png"
height="20"
alt="지디넷코리아"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="092"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="092"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=092"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="092"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="003"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/003.png"
height="20"
alt="뉴시스"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="003"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="003"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=003"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="003"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="904"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/904.png"
height="20"
alt="JTBC"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="904"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="904"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=904"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="904"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="011"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/011.png"
height="20"
alt="서울경제"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="011"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="011"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=011"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="011"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="139"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/139.png"
height="20"
alt="스포탈코리아"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="139"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="139"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=139"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="139"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="023"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/up/2020/0903/nsd185255316.png"
height="20"
alt="조선일보"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="023"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="023"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=023"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="023"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="109"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/up/2020/0610/nsd151458769.png"
height="20"
alt="OSEN"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="109"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="109"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=109"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="109"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="047"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/047.png"
height="20"
alt="오마이뉴스"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="047"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="047"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=047"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="047"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="214"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/214.png"
height="20"
alt="MBC"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="214"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="214"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=214"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="214"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="016"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/016.png"
height="20"
alt="헤럴드경제"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="016"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="016"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=016"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="016"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="330"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/330.png"
height="20"
alt="중앙데일리"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="330"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="330"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=330"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="330"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="339"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/339.png"
height="20"
alt="경기일보"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="339"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="339"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=339"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="339"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="926"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/926.png"
height="20"
alt="중부일보"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="926"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="926"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=926"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="926"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="909"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/909.png"
height="20"
alt="기호일보"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="909"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="909"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=909"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="909"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="384"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/384.png"
height="20"
alt="한국대학신문"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="384"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="384"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=384"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="384"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="984"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/984.png"
height="20"
alt="낚시춘추"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="984"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="984"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=984"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="984"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="013"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/013.png"
height="20"
alt="연합인포맥스"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="013"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="013"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=013"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="013"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="914"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/914.png"
height="20"
alt="뉴스핌"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="914"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="914"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=914"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="914"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="050"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/up/2020/0928/nsd125033437.png"
height="20"
alt="한경비즈니스"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="050"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="050"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=050"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="050"
>기사보기</a
>
</div>
</div>
<div
class="thumb_box _NM_NEWSSTAND_THUMB _NM_NEWSSTAND_THUMB_press_valid"
data-pid="312"
>
<a href="#" class="thumb">
<img
src="https://s.pstatic.net/static/newsstand/2020/logo/light/0604/312.png"
height="20"
alt="텐아시아"
class="news_logo"
/>
<span class="thumb_dim"></span
></a>
<div class="popup_wrap">
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_subscribe_press"
data-pid="312"
data-clk="sub"
>구독</a
>
<a
href="#"
role="button"
class="btn_popup _NM_NEWSSTAND_THUMB_unsubscribe_press"
data-pid="312"
data-clk="unsub"
>해지</a
>
<a
href="http://newsstand.naver.com/?list=&pcode=312"
target="_blank"
class="btn_popup"
data-clk="logo"
data-pid="312"
>기사보기</a
>
</div>
</div>
</div>
</div>
</div>
  </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_invalid" style="display:none"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg">해당 언론사 사정으로 접근이 일시 제한됩니다.</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE">확인</a> </div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_undescribe_confirm" style="display:none" data-clk-sub="*a"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE" data-clk="usclose"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg"><strong class="NM_NEWSSTAND_POPUP_PNAME"></strong>을(를)<br/>구독해지 하시겠습니까?</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CONFIRM" data-clk="usdone">확인</a> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE" data-clk="uscancel">취소</a> </div> </div> <div class="ly_toast NM_NEWSSTAND_TOAST" style="display:none"> <p class="toast_msg">구독한 언론사에 추가되었습니다.</p> </div> </div> <div id="NM_NEWSSTAND_MY_LIST" class="group_news" style="display:none" data-clk-prefix="nsd_myn"> <a href="#" role="button" class="pm_btn_prev_l _NM_NEWSSTAND_LIST_prev_btn" data-clk-custom="prev"><i class="ico_btn"></i><span class="blind">이전</span></a> <a href="#" role="button" class="pm_btn_next_l _NM_NEWSSTAND_LIST_next_btn" data-clk-custom="next"><i class="ico_btn"></i><span class="blind">다음</span><span class="blind">다음</span></a> <div class="list_view"> <div class="option_area"> <div class="list_option_wrap"> <ul class="list_option _NM_NEWSSTAND_MY_presslist"> <!-- nvpaperlist:empty --> </ul> </div> </div> <div class="_NM_NEWSSTAND_ARTICLE_CONTAINER" data-clk-sub="*a">  </div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_invalid" style="display:none"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg">해당 언론사 사정으로 접근이 일시 제한됩니다.</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE">확인</a> </div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_undescribe_confirm" style="display:none" data-clk-sub="*a"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE" data-clk="usclose"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg"><strong class="NM_NEWSSTAND_POPUP_PNAME"></strong>을(를)<br>구독해지 하시겠습니까?</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CONFIRM" data-clk="usdone">확인</a> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE" data-clk="uscancel">취소</a> </div> </div> </div> <div id="NM_NEWSSTAND_MY_THUMB" class="group_news" style="display:none" data-clk-prefix="nsd_myn"> <a href="#" role="button" class="pm_btn_prev_l _NM_UI_PAGE_PREV" data-clk-custom="prev"><i class="ico_btn"><span class="blind">이전</span></i></a> <a href="#" role="button" class="pm_btn_next_l _NM_UI_PAGE_NEXT" data-clk-custom="next"><i class="ico_btn"><span class="blind">다음</span></i></a> <div class="_NM_UI_PAGE_CONTAINER" data-clk-sub="*p"></div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_invalid" style="display:none"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg">해당 언론사 사정으로 접근이 일시 제한됩니다.</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE">확인</a> </div> </div> <div class="ly_popup NM_NEWSSTAND_POPUP NM_NEWSSTAND_undescribe_confirm" style="display:none" data-clk-sub="*a"> <a href="#" role="button" class="btn_close NM_NEWSSTAND_POPUP_CLOSE" data-clk="usclose"><i class="ico_close"></i><span class="blind">닫기</span></a> <p class="popup_msg"><strong class="NM_NEWSSTAND_POPUP_PNAME"></strong>을(를)<br>구독해지 하시겠습니까?</p> <div class="popup_btn"> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CONFIRM" data-clk="usdone">확인</a> <a href="#" role="button" class="btn_confirm NM_NEWSSTAND_POPUP_CLOSE" data-clk="uscancel">취소</a> </div> </div> </div> <div id="NM_NEWSSTAND_MY_EMPTY" class="group_news" style="display:none"> <div class="error_view"> <div class="error_area"> <strong class="error_msg">구독한 언론사가 없습니다.</strong> <p class="dsc_msg">언론사 구독 설정에서 관심있는 언론사를 구독하시면<br>언론사가 직접 편집한 뉴스들을 네이버 홈에서 바로 보실 수 있습니다.</p> <a href="http://newsstand.naver.com/config.html" class="link_redirect" target="_blank">언론사 구독 설정하기</a> </div> </div> </div> </div> </div> <!-- EMPTY --> <div id="NM_THEMECAST_CONTENTS_CONTAINER"> <div id="themecast" class="sc_themecast id_school" >
	<h2 class="blind">주제별 캐스트</h2>
	<div class="theme_head">
		<div class="group_title">
	<div class="title_area">
		<strong class="title">오늘 읽을만한 글</strong><span class="dsc">주제별로 분류된 다양한 글 모음</span>
	</div>
	<div class="info_area">

			<span class="info"><strong class="new">1,793</strong> 개의 글</span>

		<a id="NM_THEME_EDIT_SET" href="#" role="button" class="btn_set" data-clk="tca.like">관심주제 설정</a>
	</div>
</div>
<div class="theme_fix_wrap">
	<div id="NM_THEME_CATE_GROUPS" class="group_category" data-demo-key="default">
		<div class="main_category">
			<a href="#" role="button" class="pm_btn_prev NM_THEME_PREV" data-clk="tct.prev" style="display: none;">
				<i class="ico_btn"><span class="blind">이전</span></i>
			</a>
			<a href="#" role="button" class="pm_btn_next NM_THEME_NEXT" data-clk="tct.next" style="display: none;">
				<i class="ico_btn"><span class="blind">다음</span></i>
			</a>
			<div id="NM_THEME_CATE_FLICK" class="_NM_UI_PAGE_CONTAINER" style="height: 49px; overflow: hidden;">

					<div style="width: 750px;">
						<ul class="list_category" role="tablist">

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_enter"
									   aria-selected="false"
									   data-clk="tct.tvc" data-panel-code="ENTER">엔터</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_sports"
									   aria-selected="false"
									   data-clk="tct.spo" data-panel-code="SPORTS">스포츠</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_cargame"
									   aria-selected="false"
									   data-clk="tct.aut" data-panel-code="CARGAME">자동차</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_bboom"
									   aria-selected="false"
									   data-clk="tct.web" data-panel-code="BBOOM">웹툰</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_finance"
									   aria-selected="false"
									   data-clk="tct.fin" data-panel-code="FINANCE">경제M</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_living"
									   aria-selected="false"
									   data-clk="tct.fod" data-panel-code="LIVING">푸드</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_gameapp"
									   aria-selected="false"
									   data-clk="tct.gam" data-panel-code="GAMEAPP">게임</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_movie"
									   aria-selected="false"
									   data-clk="tct.mov" data-panel-code="MOVIE">영화</a>
								</li>

						</ul>
					</div>

					<div style="width: 750px;">
						<ul class="list_category" role="tablist">

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_job"
									   aria-selected="false"
									   data-clk="tct.job" data-panel-code="JOB">JOB&amp;</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_ittech"
									   aria-selected="false"
									   data-clk="tct.tec" data-panel-code="ITTECH">테크</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_travel"
									   aria-selected="false"
									   data-clk="tct.tra" data-panel-code="TRAVEL">여행+</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_science"
									   aria-selected="false"
									   data-clk="tct.sci" data-panel-code="SCIENCE">과학</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_livinghome"
									   aria-selected="false"
									   data-clk="tct.lif" data-panel-code="LIVINGHOME">리빙</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_health"
									   aria-selected="false"
									   data-clk="tct.hea" data-panel-code="HEALTH">건강</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_business"
									   aria-selected="false"
									   data-clk="tct.bsn" data-panel-code="BUSINESS">비즈니스</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_wedding"
									   aria-selected="false"
									   data-clk="tct.wed" data-panel-code="WEDDING">연애·결혼</a>
								</li>

						</ul>
					</div>

					<div style="width: 750px;">
						<ul class="list_category" role="tablist">

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_culture"
									   aria-selected="false"
									   data-clk="tct.bok" data-panel-code="CULTURE">책문화</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_momkids"
									   aria-selected="false"
									   data-clk="tct.mom" data-panel-code="MOMKIDS">부모i</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_law"
									   aria-selected="false"
									   data-clk="tct.law" data-panel-code="LAW">법률</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_beauty"
									   aria-selected="false"
									   data-clk="tct.bty" data-panel-code="BEAUTY">패션뷰티</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_animal"
									   aria-selected="false"
									   data-clk="tct.ani" data-panel-code="ANIMAL">동물공감</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_design"
									   aria-selected="false"
									   data-clk="tct.des" data-panel-code="DESIGN">디자인</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_china"
									   aria-selected="false"
									   data-clk="tct.chn" data-panel-code="CHINA">중국</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_farm"
									   aria-selected="false"
									   data-clk="tct.far" data-panel-code="FARM">FARM</a>
								</li>

						</ul>
					</div>

					<div style="width: 750px;">
						<ul class="list_category" role="tablist">

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_show"
									   aria-selected="false"
									   data-clk="tct.sow" data-panel-code="SHOW">공연전시</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_with"
									   aria-selected="false"
									   data-clk="tct.pub" data-panel-code="WITH">함께N</a>
								</li>

								<li class="category_item" role="presentation">


									<a href="#" role="tab" class="_NM_THEME_CATE tab id_school"
									   aria-selected="true"
									   data-clk="tct.scl" data-panel-code="SCHOOL">스쿨잼</a>
								</li>

						</ul>
					</div>

			</div>
		</div>
	</div>
</div>

	</div>
	<div class="theme_cont" data-panel-code="SCHOOL">
		<div class="group_topstory" data-block-id="6048717d2f7a52795aae4a79" data-block-code="PC-THEME-SCHOOL-EDIT-AREA" data-block-type="BLOCKS" data-template-code="PC-THEMECAST-EDIT-AREA"

	 data-da="margin-top"
	 >

	<div class="topstory_inner" data-block-id="60486f96edaa7f7953ba4bb8" data-block-code="PC-THEME-SCHOOL-EDIT-AREA-ITEM" data-block-type="A-MATERIAL" data-template-code="IMAGE1"

	 >


		<div class="topstory_view ">



			<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30756099&amp;memberNo&#x3D;34921815" class="topstory_thumb"
			   data-clk="tcc_scl.editbigimg1"
			   target="_blank">
				<img src="https://s.pstatic.net/static/www/mobile/edit/2021/0310/cropImg_728x360_57300298961844652.png" data-src="https://s.pstatic.net/static/www/mobile/edit/2021/0310/cropImg_728x360_57300298961844652.png" alt="학생, 웹 소설가, MC… 1인 3역의 비결은?" width="364" height="180">


					<span class="thumb_bd"></span>

			</a>
			<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30756099&amp;memberNo&#x3D;34921815" class="topstory_info"
			   data-clk="tcc_scl.editbigtxt1"
			   target="_blank">

					<em class="theme_category">십대생각</em>


				<strong class="title  ">학생, 웹 소설가, MC… 1인 3역의 비결은?</strong>

					<p class="desc">1인 3역을 소화하는
멀티 고등생 플레이어.
예술고등학교 문예창작과 학생, 구독자 7만 명의 인기 웹 소설 작가, 채널 구독자 수 3,600명의 웹 예능 MC. 세 가지 역할을 한 사람이? 바로 고등학생 2학년 박지원 군의 이야기예요. 지원 군은 2018년 중학교 3학년에 웹 소설 작가로 데뷔를 했어요. 풍부한 상상력, 사물에 대한 깊이 있는 관찰력으로 </p>



					<div class="source_area">
						<span class="source"><span class="source_inner">스쿨잼</span></span>
					</div>

			</a>

		</div>

</div>
<div class="topstory_inner" data-block-id="6048713bd52d3b2d4535d956" data-block-code="PC-THEME-SCHOOL-EDIT-AREA-ITEM" data-block-type="MATERIALS" data-template-code="IMAGE3"

	 >

	<div class="list_theme_wrap type_topstory">
		<ul class="list_theme">

			<li class="theme_item">


				<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30718497&amp;memberNo&#x3D;29940531" class="theme_thumb" data-clk="tcc_scl.editsmallimg1" target="_blank">
					<img src="https://s.pstatic.net/static/www/mobile/edit/2021/0311/cropImg_196x196_57381194390196543.jpeg" data-src="https://s.pstatic.net/static/www/mobile/edit/2021/0311/cropImg_196x196_57381194390196543.jpeg" alt="‘한강의 기적’을 만든 대한민국 경제" width="98" height="98">


						<span class="thumb_bd"></span>

				</a>
				<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30718497&amp;memberNo&#x3D;29940531" class="theme_info" data-clk="tcc_scl.editsmalltxt1" target="_blank">
					<em class="theme_category">사회의 발견</em>
					<strong class="title">‘한강의 기적’을 만든 대한민국 경제 </strong>
					<div class="source_box">
						<span class="source"><span class="source_inner">어린이경제신문</span></span>
					</div>
				</a>
			</li>

			<li class="theme_item">


				<a href="https://blog.naver.com/hackersjunior/222254887163" class="theme_thumb" data-clk="tcc_scl.editsmallimg2" target="_blank">
					<img src="https://s.pstatic.net/static/www/mobile/edit/2021/0310/cropImg_196x196_57300767458144920.jpeg" data-src="https://s.pstatic.net/static/www/mobile/edit/2021/0310/cropImg_196x196_57300767458144920.jpeg" alt="글씨체 연습을 위한 팁 4가지" width="98" height="98">


						<span class="thumb_bd"></span>

				</a>
				<a href="https://blog.naver.com/hackersjunior/222254887163" class="theme_info" data-clk="tcc_scl.editsmalltxt2" target="_blank">
					<em class="theme_category">쨈이의 취미생활</em>
					<strong class="title">글씨체 연습을 위한 팁 4가지 </strong>
					<div class="source_box">
						<span class="source"><span class="source_inner">해커스 중고등영어</span></span>
					</div>
				</a>
			</li>

			<li class="theme_item">


				<a href="https://blog.naver.com/jihaksa1965/222265118124" class="theme_thumb" data-clk="tcc_scl.editsmallimg3" target="_blank">
					<img src="https://s.pstatic.net/static/www/mobile/edit/2021/0311/cropImg_196x196_57381431023386297.png" data-src="https://s.pstatic.net/static/www/mobile/edit/2021/0311/cropImg_196x196_57381431023386297.png" alt="초등학생을 위한 새 학기 국영수 공부법" width="98" height="98">


						<span class="thumb_bd"></span>

				</a>
				<a href="https://blog.naver.com/jihaksa1965/222265118124" class="theme_info" data-clk="tcc_scl.editsmalltxt3" target="_blank">
					<em class="theme_category">오늘의 Pick</em>
					<strong class="title">초등학생을 위한 새 학기 국영수 공부법 </strong>
					<div class="source_box">
						<span class="source"><span class="source_inner">상상하라 지학사</span></span>
					</div>
				</a>
			</li>

		</ul>
	</div>
</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-0" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="1"
	 >

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_501ea697-807f-11eb-a04a-c3c8b57dacae" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30792766&amp;memberNo&#x3D;24413396" class="theme_thumb" data-clk="tcc_scl.list1cont1" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279686639mGwO9.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279686639mGwO9.jpg%22&amp;type&#x3D;nf340_228" alt="식물인간 상태에서 깨어난 소녀의 놀라운 근황" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30792766&amp;memberNo&#x3D;24413396" class="theme_info" data-clk="tcc_scl.list1cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">식물인간 상태에서 깨어난 소녀의 놀라운 근황</strong>
						<p class="desc">&quot;위대한 동기부여 스토리, 이것은 기적이다!&quot;12년 동안 셀 수 없는 사망 선고를 받았던 빅토리아 알렌의 생존과 가족, 특별한 믿음을 담은 『나는 나를 포기하지 않는다』는 많은 독자에게 큰 울림과 감동을 주었다. 대부분 깨닫지 못하지만, 우리는 우리를 아래로 끌어내리려는 힘과 싸우고 있다. 하지만 그때마다 위로 헤엄칠지 아래로 가라앉을지는</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">가나출판사</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_501ea699-807f-11eb-a04a-ede154f087e0" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30809806&amp;memberNo&#x3D;5149148" class="theme_thumb" data-clk="tcc_scl.list1cont2" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279850294weDDg.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279850294weDDg.jpg%22&amp;type&#x3D;nf340_228" alt="원래의 색깔을 잃어버린 건물들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30809806&amp;memberNo&#x3D;5149148" class="theme_info" data-clk="tcc_scl.list1cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">원래의 색깔을 잃어버린 건물들</strong>
						<p class="desc">우리가 어떤 색깔의 옷을 입는지에 따라 인상이 묘하게 달라지듯 건출물 역시 표면의 색깔에 따라 분위기가 달라지기 마련입니다. 현대 건축물뿐만 아니라 그 옛날 고대 이집트로 거슬러 올라가도 풍부하게 구성된 색채 이미지를 통해 색깔의 중요성을 알 수 있는데요. 그러나 아무리 보행자들의 눈길을 사로잡는 화려한 색깔의 건물도 세월의 흐름을 비껴갈 순 없는 노릇이죠</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">하루 3분</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_3b037ee5-80b6-11eb-a785-f3b33180b1a1" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30835466&amp;memberNo&#x3D;52430444" class="theme_thumb" data-clk="tcc_scl.list1cont3" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279765817BYIOD.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615279765817BYIOD.jpg%22&amp;type&#x3D;nf340_228" alt="알고 보니 모델 출신인 배우 5" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30835466&amp;memberNo&#x3D;52430444" class="theme_info" data-clk="tcc_scl.list1cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">알고 보니 모델 출신인 배우 5</strong>
						<p class="desc">다른 세계에 살고 있는 것 같다고 평가되는 모델들! 큰 키와 더불어 일반인과는 클라스가 다른 다리 길이와 작은 얼굴까지 :D 슬쩍 지나치기만 해도 모델 포스가 풀풀 풍기는 프로 모델들 중 배우로 전향에 성공한 사람들이 있죠큰 키에 이목을 사로 잡고 연기력까지 갖춘 모델 출신 배우들은 각종 드라마나 영화의 주연을 맡으면서 최근에는 배우와 모델 활동을 겸업하는</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">SCLab 스크랩</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_52b8b333-807f-11eb-83fb-a1d12ae44c83" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30797144&amp;memberNo&#x3D;339226" class="theme_thumb" data-clk="tcc_scl.list1cont4" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615280567961LacVx.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615280567961LacVx.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;어째서 이런 일이...&quot;
최악의 하루를 보낸 사람들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30797144&amp;memberNo&#x3D;339226" class="theme_info" data-clk="tcc_scl.list1cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"어째서 이런 일이..."
최악의 하루를 보낸 사람들</strong>
						<p class="desc">최악의 하루를 보낸 사람들[아이디어 래빗] 세상의 모든 것들이 마음대로 흘러가는 것은 아니다. 생각했던 만큼 좋은 결과를 얻을 수 있는 날이 있는가 하면, 생각 이상으로 안 좋은 사건이 일어나 끔찍한 하루를 보내는 날도 있다. 전혀 예측하지 못한 부분에서 일어나는 해프닝은 사람들에게 많은 실망감도 안겨준다.세상만사 모든 것들을 생각하는 대로 바꿀 수는 없지</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">아이디어 래빗</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-1" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="1"
	 >

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_684564f7-815a-11eb-a785-0df960e6ab5b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30815631&amp;memberNo&#x3D;39207624" class="theme_thumb" data-clk="tcc_scl.list2cont1" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615353218323aKg0f.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615353218323aKg0f.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;언니 미안해&quot; 윗집 아이가 준 선물과 손편지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30815631&amp;memberNo&#x3D;39207624" class="theme_info" data-clk="tcc_scl.list2cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"언니 미안해" 윗집 아이가 준 선물과 손편지</strong>
						<p class="desc">윗집 층간소음 때문에 고민이 많았던 A씨는 어느 날 생각지도 못한 선물과 손편지를 받았다. “언니, 층간소음 미안해. 맛있게 먹어” 이렇게 적힌 쪽지와 함께 선물이 전달됐다. A씨는 그동안 상했던 마음이 사르르 녹았다고. 지난해 한 온라인 커뮤니티에는 “우리집 층간소음”이라는 제목으로 A씨의 사연이 공개됐다.A씨는</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">NTD Korea</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_684564f6-815a-11eb-a785-df9f3abba00b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30784385&amp;memberNo&#x3D;11880830" class="theme_thumb" data-clk="tcc_scl.list2cont2" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615352973909MUV2j.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615352973909MUV2j.jpg%22&amp;type&#x3D;nf340_228" alt="탈출한 고양이 찾아준 지하철 영웅들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30784385&amp;memberNo&#x3D;11880830" class="theme_info" data-clk="tcc_scl.list2cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">탈출한 고양이 찾아준 지하철 영웅들</strong>
						<p class="desc">이해림 역무원은 지난 1월 서울 지하철 4호선 성신여대입구역에서 담요에 싸인 고양이를 발견했다. 그는 고양이를 보호하고 있다가 실종 전단을 찾았다. 이 역무원은 주인에게 연락해 고양이를 직접 돌려줬다. 고양이 주인은 “30만원을 사례하겠다”고 했지만 이 역무원은 이를 정중히 거절했다. 지난해 12월엔 서울 지하철 1호선 서울역에서 휴대용 우리에 있던 고양이</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">중앙일보</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_369ca365-8568-11eb-a4a8-53b3f728e003" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30691428&amp;memberNo&#x3D;15460571" class="theme_thumb" data-clk="tcc_scl.list2cont3" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0315%2Fupload_1615796817680mUJtw.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0315%2Fupload_1615796817680mUJtw.jpg%22&amp;type&#x3D;nf340_228" alt="요즘 학생들이 받고 싶어 한다는 선물 10가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30691428&amp;memberNo&#x3D;15460571" class="theme_info" data-clk="tcc_scl.list2cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">요즘 학생들이 받고 싶어 한다는 선물 10가지</strong>
						<p class="desc">고가부터 중저가까지 모두 모았다 선물은 무릇 받는 사람이 기뻐할만한 것을 해야 하지만, 나와 연령대도, 라이프스타일도, 취향도 다른 사람이 마음에 들어 할 만한 것을 고른다는 것은 매우 어려운 일이다. 더구나 그 상대가 어른들과는 다른 세상에 살고 있는, 게다가 예민한 감수성과 종잡을 수 없는 취향을 가진 중고생이라면 더더욱 고민이 되기 마련이다. 자녀, </p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">데일리</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_369ca364-8568-11eb-a4a8-69cef90a8a95" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30463319&amp;memberNo&#x3D;25827089" class="theme_thumb" data-clk="tcc_scl.list2cont4" target="_blank">
						<img src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0303%2Fupload_1614751095617NdBMF.jpg%22&amp;type&#x3D;nf340_228" data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0303%2Fupload_1614751095617NdBMF.jpg%22&amp;type&#x3D;nf340_228" alt="도대체 왜 없어진 거야! 단종된 과자 모음" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30463319&amp;memberNo&#x3D;25827089" class="theme_info" data-clk="tcc_scl.list2cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">도대체 왜 없어진 거야! 단종된 과자 모음</strong>
						<p class="desc">이 까까 대체 왜 없어진거냐ㅠㅠ 단종과자 베스트...☆안녕하세요! 다운맛집투어입니다 :) 요즘 집콕생활이 계속되다보니 아무래도 입이 자꾸 심심하고- 손이 심심하고.... ㅋㅋㅋㅋ 그래서 자꾸 뭘 꺼내먹게 되는 것 같은데요 그 중 하나는 바로 과자가 아닐까싶어요.먹어도 먹어도 맛있음이 한도초과..! 계속 먹게되는 맛있는 까까들 근데 이거 왜 사라진거냐</p>
						<div class="source_box">
							<span class="date">2개월 전</span>
							<span class="source"><span class="source_inner">다운맛집투어</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-2" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="2"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_369ca366-8568-11eb-a4a8-11dd6d46ded3" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30616748&amp;memberNo&#x3D;41062464" class="theme_thumb" data-clk="tcc_scl.list3cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0303%2Fupload_1614739528306eEV4V.jpg%22&amp;type&#x3D;nf340_228" alt="스팸 생으로 먹어도 괜찮을까?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30616748&amp;memberNo&#x3D;41062464" class="theme_info" data-clk="tcc_scl.list3cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">스팸 생으로 먹어도 괜찮을까?</strong>
						<p class="desc">어느새 한국이 밥도둑 중 하나로 자리잡은 스팸. 하얀 쌀밥에 스팸 한 조각이면 충분하다고 하는 사람들이 많습니다. 단연 명절 선물로도 인기가 많은 스팸. 종종 TV에서도 연예인들이 밥 반찬으로 스팸을 먹는 모습을 볼 수 있습니다. 하지만 스팸을 굽지 않고 뚜껑만 열어서 숫가락으로 떠먹는 연예인들의 모습에 스팸을 구워먹는 사람들은 놀랄 수 밖에 없죠. 실제로</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">스마트 1분</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2eed4395-8067-11eb-a785-251c822fa1f2" data-da-position="true">
					<a href="https://blog.naver.com/sedrjk/222165181572" class="theme_thumb" data-clk="tcc_scl.list3cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615265644365Ue6jr.jpg%22&amp;type&#x3D;nf340_228" alt="아이패드로 그리는 스크래치페이퍼" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/sedrjk/222165181572" class="theme_info" data-clk="tcc_scl.list3cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">아이패드로 그리는 스크래치페이퍼</strong>
						<p class="desc">#아이패드공부 3탄#아이패드스크래치페이퍼​어릴때 크레파스를 이용해그렸던게 생각이났어요ㅋㅋ아이패드로도 할 수 있다니🤭​이번편도 쉽습니다!그럼바로 고고❤​​새페이지를 만들어서내 맘대로 원하는 색으로 채워줍니다.​​새레이어를 만들어주세요.​새레이어를 검은색으로 채워줍니다.​지우개를 눌러 원하는 브러쉬를선택해줍니다.​지우개를 브러쉬삼아 그리면바탕...</p>
						<div class="source_box">
							<span class="date">3개월 전</span>
							<span class="source"><span class="source_inner">사나운 날진</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_65dd8d15-815a-11eb-83fb-6da3380adebb" data-da-position="true">
					<a href="https://blog.naver.com/swc1969/222264222740" class="theme_thumb" data-clk="tcc_scl.list3cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_16153527944101T4dr.jpg%22&amp;type&#x3D;nf340_228" alt="치아 건강을 망치는 생활 속 행동들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/swc1969/222264222740" class="theme_info" data-clk="tcc_scl.list3cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">치아 건강을 망치는 생활 속 행동들</strong>
						<p class="desc">일상생활에서 무심코 하는 잘못된 행동은 치아 건강을 망치는 지름길! 치아 건강을 위해 주의해야 할 습관은?​​​​​양치 후 바로 가글 하는 습관수시로 가글 하는 것은 오히려 치아 건강을 망치는 좋지 않은 습관인데요. 치약의 계면활성제와 가글 속의 염화물이 만나면 치아 변색이 일어날 수 있기 때문에 주의하는 것이 좋습니다. 가글은 양치질을 하고 30분 후에 </p>
						<div class="source_box">
							<span class="date">1주일 전</span>
							<span class="source"><span class="source_inner">수원여자대학교</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2d72d893-8067-11eb-a785-6f247ef0b1da" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30626399&amp;memberNo&#x3D;33296067&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list3cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615258269504Y3w7A.jpg%22&amp;type&#x3D;nf340_228" alt="수학을 잘하기 위해 알아야 할 3가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30626399&amp;memberNo&#x3D;33296067&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list3cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">수학을 잘하기 위해 알아야 할 3가지</strong>
						<p class="desc">송재환 선생님의 수학 실력 향상법수학교육 전문가가 알려주는수학 실력을 키우는 방법 “선생님, 수학을 어떻게 하면 잘하게 할 수 있을까요?” 교사를 하면서 학부모들로부터 수없이 받는 질문입니다. 저는 이 질문에 이렇게 답변드리고 싶습니다.  “수학의 개념, 원리, 법칙에 대해 이해를 하고 암기를 하게 하세요.” 수학과의 목표는 ‘수학의 개념, 원리, 법칙의 </p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">비상교육</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2eed4396-8067-11eb-a785-fde0233a6cac" data-da-position="true">
					<a href="https://blog.naver.com/qmfosej/222242825087" class="theme_thumb" data-clk="tcc_scl.list3cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615266063464kuSIh.jpg%22&amp;type&#x3D;nf340_228" alt="콘옥수수는 필수! 집에서 타코야끼 만들어 먹기" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/qmfosej/222242825087" class="theme_info" data-clk="tcc_scl.list3cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">콘옥수수는 필수! 집에서 타코야끼 만들어 먹기</strong>
						<p class="desc">​​안녕하세요 여러분블로거 태은님이에요^ㅅ^​다들 명절 잘 보내셨나유? 저는 거의 집에만 있다싶이한 명절이었어서 본가에서 열심히 댕댕이랑 놀고있어요그래서인지 이것저것 먹을 게 생각이 많이나더라구요​특히나 서울 있을때 그렇게나 많이 사먹던 아이가본가 내려오니까 어찌나 생각이 많이 나는지몰라요ㅋㅋ그렇게 시작한게 바로! 오늘!! 타코야끼 만들기에요​​​​...</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">태은님</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-3" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="2"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_65dd8d14-815a-11eb-83fb-177e69e14b2d" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30837545&amp;memberNo&#x3D;29949587" class="theme_thumb" data-clk="tcc_scl.list4cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615352522824IXAuT.jpg%22&amp;type&#x3D;nf340_228" alt="성공한 부자들의 사소한 습관 6가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30837545&amp;memberNo&#x3D;29949587" class="theme_info" data-clk="tcc_scl.list4cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">성공한 부자들의 사소한 습관 6가지</strong>
						<p class="desc">[인사이트] 원혜진 기자 &#x3D; &quot;습관은 미래의 나를 비추는 거울이다&quot;라는 말이 있다.작은 생각, 행동 등 당장은 큰 변화를 느낄 수 없는 사소한 습관은 결국 인생을 통째로 바꾸는 견인 역할을 한다.아무리 사소한 행동도 꾸준히 하려면 어렵듯 세계적인 부자들 역시 인생을 바꾸기 위해 혹독하게 습관을 다스렸다.결국엔 부와 명성을 얻고 보란 듯이 성공한 부자들의 사</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">인사이트</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_28c57d1b-8067-11eb-a785-e753e6a51209" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30806477&amp;memberNo&#x3D;21959512&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list4cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_16152559440031uyON.jpg%22&amp;type&#x3D;nf340_228" alt="요즘 SNS에서 핫하다는 ○○ 인플루언서" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30806477&amp;memberNo&#x3D;21959512&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list4cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">요즘 SNS에서 핫하다는 ○○ 인플루언서</strong>
						<p class="desc">AI 기술 기반의 인플루언서 ‘루이’, ‘이터니티’, ‘로지’ 기업과 소비자가 가상 인플루언서에 열광하는 이유수많은 팔로워를 거느리며 대중에게 막대한 영향력을 끼치는 인플루언서. 이들은 단순한 SNS 유저를 넘어 MZ세대의 21세기형 ‘우상’이 되어가고 있다. 인플루언서&amp;</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">위키트리 WIKITREE</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_28c57d1c-8067-11eb-a785-0df2b59254cd" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30787354&amp;memberNo&#x3D;21527483&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list4cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615256631516FRKWx.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;어? 이거 난데!&quot; 은근 잘 맞는 색채 심리테스트" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30787354&amp;memberNo&#x3D;21527483&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list4cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"어? 이거 난데!" 은근 잘 맞는 색채 심리테스트</strong>
						<p class="desc">비트맵군: 안녕하세요~ 디자이너 여러분! 항상 유익한 꿀팁을 전해드리는 비트맵군입니다! 지난 번에는 벡터양이 색상 조합에 대해 꿀팁을 알려드렸는데요! 오늘은 색을 활용해 심리를 테스트할 수 있는 신기한 색채심리테스트를 소개해드릴려고 한답니다! ​ 색이 참 신기한 점은 같은 색상이라도, 살아온 환경이나 성향, 경험, 취향 등에 따라 사람마다 다르게 본다는 것</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">라우드소싱 포스트</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2d72d894-8067-11eb-a785-45364524d194" data-da-position="true">
					<a href="https://blog.naver.com/ebsmath1/222243963051" class="theme_thumb" data-clk="tcc_scl.list4cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615258385870Nt2SH.jpg%22&amp;type&#x3D;nf340_228" alt="이것은 무엇을 회전시킨 모양일까?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/ebsmath1/222243963051" class="theme_info" data-clk="tcc_scl.list4cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">이것은 무엇을 회전시킨 모양일까?</strong>
						<p class="desc">안녕하세요!EBSMath입니다!​​​​오늘은 원기둥, 원뿔, 구와 관련된내용을 준비했어요!​함께 학습해 볼까요?​​​​자, 여길 보세요!이 평면도형을 한 직선을 기준으로1회전 돌렸습니다!​​​​그 자체로 생기는 입체도형을&quot;회전체&quot;라 부릅니다​그리고 기준이 되는 직선을&quot;회전축&quot;이라 하죠!​​​​회전체를 다시 한번 살펴볼까요?​이 평면도형...</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">EBSMath</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2b20d1ec-8067-11eb-a04a-23650058bc9c" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30844028&amp;memberNo&#x3D;1019021&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list4cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615250474845Em8BV.jpg%22&amp;type&#x3D;nf340_228" alt="3월 신학기를 맞아 읽으면 좋은 책  4" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30844028&amp;memberNo&#x3D;1019021&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list4cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">3월 신학기를 맞아 읽으면 좋은 책  4</strong>
						<p class="desc">멀기만 했던 3월이 드디어 우리 곁으로 찾아왔습니다. 설레기도 하고, 한편으론 조금 떨리는 새학기에 청소년들에게 꼭 추천하고 싶은 책들을 키워드별로 골라서 모아보았어요.#다양성 #존중 #보통 #나만의나 이희영, 『보통의 노을』 노을은 작은 공방을 운영하는 엄마와 단둘이 살고 있다. 열일곱 살에 노을을 낳은 엄마는 가뜩이나 젊은 나이에 동안이기까지 하다. 그</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">자음과모음</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-4" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="3"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_28c57d1a-8067-11eb-a785-950b6b2e1834" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30809460&amp;memberNo&#x3D;339226&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list5cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615256011009QB16c.jpg%22&amp;type&#x3D;nf340_228" alt="카레에 땅콩버터를? 의외의 음식 꿀조합" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30809460&amp;memberNo&#x3D;339226&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list5cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">카레에 땅콩버터를? 의외의 음식 꿀조합</strong>
						<p class="desc">치즈 케이크 + 김치고정 관념을 깨면 의외로 맛있는 음식 조합이 많다. 그중 가장 신세계는 바로 치즈케이크 위에 김치를 올려 먹는 것이다. SBS의 예능 프로그램 &#x27;자기야-백년손님&#x27;에 출연한 이연복 셰프에 의해 알려진 &#x27;치즈 케이크 + 김치&#x27; 조합은, 김치 특유의 맛이 치즈 케이크의 느끼함을 잘 잡아주어 신세계의 맛을 느낄 수 있다고 한다.맥주 + 후추후추</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">아이디어 래빗</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2a017f8e-8067-11eb-a785-af3bad0a7681" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30813323&amp;memberNo&#x3D;42690419&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list5cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615264196775zbwLu.jpg%22&amp;type&#x3D;nf340_228" alt="커플보다 빛나는 절친 스타들의 시밀러룩!" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30813323&amp;memberNo&#x3D;42690419&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list5cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">커플보다 빛나는 절친 스타들의 시밀러룩!</strong>
						<p class="desc">[갓잇코리아 / 오혜인 기자] 과거 커플룩의 공식은 같은 옷을 함께 입는 것이었다. 하지만 MZ 세대는 진부한 커플룩 보다, 같은 듯 다른 시밀러 룩에 열광하고 있다. 시밀러 룩이란, 유사한, 비슷한이라는 뜻을 갖고 있으며 연인 또는 친구 등과 옷을 맞춰 입을 때 같은 옷을 선택하는 것이 아닌 패턴이나 소재 등을 비슷하게 맞춰 통일된 느낌을 살리는 스타일링</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">갓잇코리아</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_28c57d19-8067-11eb-a785-1581b2c5b975" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30745984&amp;memberNo&#x3D;34921815&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list5cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615256595875EBPiA.jpg%22&amp;type&#x3D;nf340_228" alt="피할 수 없는 인간관계의 어려움" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30745984&amp;memberNo&#x3D;34921815&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list5cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">피할 수 없는 인간관계의 어려움</strong>
						<p class="desc">해마다 3월은 학교폭력 사안이 많이 발생하는 시기입니다. 신학기라 새로운 환경에 놓이게 된 학생들이 정서적으로 불안감이 있는 데다 친구들까지 낯설기 때문에 불필요한 마찰이 생기기 쉽지요. 새로운 학교, 새로운 선생님, 새로운 친구 등 새롭지만 모든 게 낯설 수밖에 없는 3월은 그래서 학교마다 긴장할 수밖에 없는 시기이기도 합니다.우리는 살면서 조직을 벗어날</p>
						<div class="source_box">
							<span class="date">1주일 전</span>
							<span class="source"><span class="source_inner">스쿨잼</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2a017f8d-8067-11eb-a785-e5346b8aa81f" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30687362&amp;memberNo&#x3D;51907070" class="theme_thumb" data-clk="tcc_scl.list5cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_16152574656825ZCsq.jpg%22&amp;type&#x3D;nf340_228" alt="하루에 240만 원...? 입이 떡 벌어지는 비행기 주차 비용" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30687362&amp;memberNo&#x3D;51907070" class="theme_info" data-clk="tcc_scl.list5cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">하루에 240만 원...? 입이 떡 벌어지는 비행기 주차 비용</strong>
						<p class="desc">동영상  버튼을 누르면 현재 화면에서 재생됩니다. 코로나 때문에 날지 못하는 비행기 주차료, 얼마나 나올까?｜크랩 #크랩 #비행기 #공항여름 휴가 시즌이지만, 여전한 코로나의 위세 때문에 해외로 나가는 사람은 거의 없습니다. 그런데 이렇게 다들 국내로만 휴가를 떠난다면, 그 동안 수많은 사람을 실어 날랐던 비행기들은 뭘 하고 있을까요? 비행기는 그 남다른 </p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">KLAB</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_cf7227a8-816f-11eb-a785-c778a7819939" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30718600&amp;memberNo&#x3D;51907070" class="theme_thumb" data-clk="tcc_scl.list5cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0226%2Fupload_1614319130005GJ9TW.jpg%22&amp;type&#x3D;nf340_228" alt="햄버거 안 흘리고 먹는 간단한 방법" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30718600&amp;memberNo&#x3D;51907070" class="theme_info" data-clk="tcc_scl.list5cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">햄버거 안 흘리고 먹는 간단한 방법</strong>
						<p class="desc">누구나 위쪽 빵이 하늘을 향하게끔 들고 먹는 햄버거! 그런데 원래는 뒤집어 먹는 게 맞다고요?! 과학자들이 알려주는 ‘햄버거 과학적으로 먹는 방법’도 함께 소개해 드립니다햄버거, 간단하게 한 끼 때우기 편한 음식이지만 은근히 먹기 까다롭습니다턱에 구멍 난 것처럼 소스를 흘리고, 내용물을 떨어뜨리기에 십상이죠종이로 잘 감싸고 먹어도 결국</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">KLAB</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-5" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="3"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_cf7227aa-816f-11eb-a785-e7c3c55b5d88" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30746417&amp;memberNo&#x3D;29949587" class="theme_thumb" data-clk="tcc_scl.list6cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0224%2Fupload_1614151037792ByLDK.jpg%22&amp;type&#x3D;nf340_228" alt="실물보다 잘 나오게 증명사진 찍는 방법 5" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30746417&amp;memberNo&#x3D;29949587" class="theme_info" data-clk="tcc_scl.list6cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">실물보다 잘 나오게 증명사진 찍는 방법 5</strong>
						<p class="desc">[인사이트] 조세진 기자 &#x3D; &quot;하... 또 망했어!&quot;새 학기, 취업 시즌이 돌아오면서 증명사진을 찍는 사람들이 늘어났다.증명사진은 이력서나 각종 신분증에 들어간다. 때문에 당신의 첫인상을 결정짓기도 하는 중요한 요소로 작용한다.하지만 단단히 굳어버린 표정, 어색한 웃음 등 &#x27;셀카&#x27;가 익숙한 이들에게 증명사진은 그저 어색하기만 하다.&quot;이번에도 망했다!&quot;는 말</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">인사이트</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_cf7227a9-816f-11eb-a785-4f74d8fdc671" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30733577&amp;memberNo&#x3D;29949587" class="theme_thumb" data-clk="tcc_scl.list6cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615360272597PAmND.jpg%22&amp;type&#x3D;nf340_228" alt="가장 먼저 눈에 띄는 &#x27;색깔&#x27;로 알아보는 나의 강점" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30733577&amp;memberNo&#x3D;29949587" class="theme_info" data-clk="tcc_scl.list6cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">가장 먼저 눈에 띄는 '색깔'로 알아보는 나의 강점</strong>
						<p class="desc">[인사이트] 김나영 기자 &#x3D; 다양한 색깔이 오묘하게 섞여 있는 그림 한 장.지금 이 그림을 보았을 때 당신은 가장 먼저 무슨 색이 눈에 들어왔는가.그림 한 장으로 알아보는 &#x27;성격 테스트&#x27;가 누리꾼들 사이에서 폭발적인 반응을 얻고 있다.자 이제 마음을 가다듬고 주어진 그림을 똑바로 바라보자. 당신은 분홍색, 흰색, 노란색, 파란색, 보라색 중 어떤 색깔이 가</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">인사이트</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_27a4073b-8067-11eb-a04a-97c4e643815b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30786244&amp;memberNo&#x3D;45922277&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list6cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_16152552622388SwGO.jpg%22&amp;type&#x3D;nf340_228" alt="나뭇잎인 줄 알고 만졌다가는...!" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30786244&amp;memberNo&#x3D;45922277&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list6cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">나뭇잎인 줄 알고 만졌다가는...!</strong>
						<p class="desc">등산을 가면 다양한 곤충 친구들을 볼 수 있어요. 그중에서도 참나무산누에나방은 흔히 볼 수 있는 곤충이지요. 성충(어른벌레)은 6월부터 8월까지 출현해 여름에 만날 수 있답니다.  자료 : 위키피디아 커먼즈. https://ko.m.wikipedia.org/wiki/%ED%8C%8C%EC%9D%BC:Antheraea_yamamai_-_male_1_(HS).</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">바이킹</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_cf7227ab-816f-11eb-a785-55302b92096f" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30723212&amp;memberNo&#x3D;27875303" class="theme_thumb" data-clk="tcc_scl.list6cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0224%2Fupload_16141517795283Qx0x.jpg%22&amp;type&#x3D;nf340_228" alt="요즘 핫한 천만 원짜리 편의점 선물의 정체" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30723212&amp;memberNo&#x3D;27875303" class="theme_info" data-clk="tcc_scl.list6cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">요즘 핫한 천만 원짜리 편의점 선물의 정체</strong>
						<p class="desc">설 연휴를 맞아 상상도 못 할 아이템이 편의점에 등장했다고 합니다. 바로 CU가 설 선물로 내놓은 ‘집’인데요. 편의점에서 파는 집이라니, 도대체 정체가 무엇일까요?CU는 지난달 설 선물로 ‘집’을 내놨습니다. 정확히 말하면 ‘이동형 주택’인데요. 이동형 주택은 공장에서 완제품으로 생산된 집을</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">매일경제</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2b20d1ed-8067-11eb-a04a-3f5d27ee971a" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30847222&amp;memberNo&#x3D;40871286" class="theme_thumb" data-clk="tcc_scl.list6cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615250522386IQqUq.jpg%22&amp;type&#x3D;nf340_228" alt="명품 브랜드가 대부분 유럽에 있는 이유는?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30847222&amp;memberNo&#x3D;40871286" class="theme_info" data-clk="tcc_scl.list6cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">명품 브랜드가 대부분 유럽에 있는 이유는?</strong>
						<p class="desc">코로나19 확산으로 인한 경기 침체 속에서도 우리나라 사람들의 명품 소비는 연일 증가세를 보였습니다. 사람들은 왜 명품에 이토록 열광하는 걸까요? 이번 시간에는 명품의 모든 것을 낱낱이 파헤쳐 봅니다. 대체 명품이 뭐길래 ‘명품(名品)’의 사전적 의미는 ‘뛰어나거나 이름난 물건 또는 작품’입니다. 장인이라 불리는 훌륭한 기술자들이 직접 손으로 제작한 물건,</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">중학독서평설</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-6" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="4"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_4b3a0e83-807f-11eb-a04a-edc33faa6929" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30800868&amp;memberNo&#x3D;37655020" class="theme_thumb" data-clk="tcc_scl.list7cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615263088341u6f3p.jpg%22&amp;type&#x3D;nf340_228" alt="아이돌 대표 남사친X여사친 모음" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30800868&amp;memberNo&#x3D;37655020" class="theme_info" data-clk="tcc_scl.list7cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">아이돌 대표 남사친X여사친 모음</strong>
						<p class="desc">보아 X 동방신기 유노윤호86년 동갑내기인 두 사람. (사실 유노윤호가 빠른 년생이라 오빠이긴 함) 다정하고 서로를 챙기는 모습에 오해가 날법도 하지만, ‘보아와는 뭘 해도 스캔들이 나지 않을 친구’라며 선 딱 그은 유노윤호.그도 그럴 것이, 데뷔 한 이후로 쭈욱 친하게 지냈으니 10년 이상 된 찐 우정임!여자친구 신비 </p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">겟꿀</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_4b3a0e80-807f-11eb-a04a-0156d9cf5188" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30688393&amp;memberNo&#x3D;34921815" class="theme_thumb" data-clk="tcc_scl.list7cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615263023517oSjIv.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;아이가 뻔한 거짓말을 자꾸 해요&quot;" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30688393&amp;memberNo&#x3D;34921815" class="theme_info" data-clk="tcc_scl.list7cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"아이가 뻔한 거짓말을 자꾸 해요"</strong>
						<p class="desc">중학생 아들인데, 밥 먹듯이 거짓말을 합니다. 사사건건 거짓말을 하고, 바로 눈앞에서 들통날 거짓말도 눈 하나 깜짝하지 않고 아무렇지 않게 하네요. 초등학생 때까지는 말도 잘 듣고, 나름 모범생이었는데, 이렇게 거짓말을 심하게 하는 걸 보니 너무 속상합니다. 아무리 혼내고, 거짓말을 하지 않기로 약속해도 소용없어요. 거짓말하는 게 습관이 돼서 너무 걱정되고</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">스쿨잼</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_632ee78c-815a-11eb-a04a-5f6d041c497f" data-da-position="true">
					<a href="https://blog.naver.com/jeewon8978/222243082625" class="theme_thumb" data-clk="tcc_scl.list7cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615352097434kZUvM.jpg%22&amp;type&#x3D;nf340_228" alt="새로 나온 닌텐도 스위치 마리오 에디션 개봉 후기" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/jeewon8978/222243082625" class="theme_info" data-clk="tcc_scl.list7cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">새로 나온 닌텐도 스위치 마리오 에디션 개봉 후기</strong>
						<p class="desc">#닌텐도스위치 #닌텐도마리오에디션 #닌텐도오프라인 #닌텐도오프라인구매 #닌텐도오프라인구매방법 #닌텐도스위치이마트 #이마트트레이더스닌텐도 #닌텐도스위치추천 #닌텐도스위치마리오 #닌텐돈스위치개봉기 #닌텐도스위치마리오에디션개봉기 #닌텐도스위치내돈내산 #닌텐도스위치마리오에디션내돈내산​​​​​오늘은 출시 당일에 구입한 따끈따끈한 닌텐도 스위치 신상을 ...</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">디오니소스</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2547c7b8-8067-11eb-a04a-3120eb9ae93f" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30839479&amp;memberNo&#x3D;25840789" class="theme_thumb" data-clk="tcc_scl.list7cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615254096652wLRHv.jpg%22&amp;type&#x3D;nf340_228" alt="샤이니 굿즈 판매까지? 다양한 아르바이트를 했던 스타 10" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30839479&amp;memberNo&#x3D;25840789" class="theme_info" data-clk="tcc_scl.list7cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">샤이니 굿즈 판매까지? 다양한 아르바이트를 했던 스타 10</strong>
						<p class="desc">TV에서 보는 스타들 중에는 무명시절 생계를 유지하기 위해 안 해 본 일이 없을 만큼 고생했다는 사람들이 있는데요. 현재는 꽃길만 걷고 있어 상상조차 안 가지만 현재의 스타 자리에 올라오게 해준 경험이라고들 말하는데요. 무슨 일을 했었을까요? 출처 : 김태리 인스타그램 출처 : 김태리 인스타그램 김태리는 귀티 나는 외모 덕분인지 알바하고는 정말 거리가 멀어</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">치어풀24</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_4db4ab75-807f-11eb-a04a-3beb3a226482" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30840515&amp;memberNo&#x3D;46129852" class="theme_thumb" data-clk="tcc_scl.list7cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615265825835RQ6js.jpg%22&amp;type&#x3D;nf340_228" alt="인테리어가 특이한 국내 스타벅스 매장들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30840515&amp;memberNo&#x3D;46129852" class="theme_info" data-clk="tcc_scl.list7cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">인테리어가 특이한 국내 스타벅스 매장들</strong>
						<p class="desc">마니아층이 탄탄한 커피전문점 스타벅스의 꾸준한 인기 비결로 차별화된 감각적인 인테리어 역시 한몫하는 듯합니다. 오늘은 이색적인 인테리어로 각광받는 전국 이색 스타벅스 매장 인테리어를 모아봤어요. 지역적 특색과 주변 자연경관이 함께 어우러지는 전국 이색 스타벅스 매장들 랜선으로 살펴보세요!:)스벅 덕후들 모여랏! 전국 이색 스타벅스 매장 인테리어 모음</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">리얼큐브</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-7" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="4"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_4b3a0e81-807f-11eb-a04a-3f7baa27f970" data-da-position="true">
					<a href="https://blog.naver.com/myelite1318/222263681323" class="theme_thumb" data-clk="tcc_scl.list8cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615263340753XN30O.jpg%22&amp;type&#x3D;nf340_228" alt="청소년만 가능! &#x27;청소년증&#x27; 발급 방법부터 혜택까지~" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/myelite1318/222263681323" class="theme_info" data-clk="tcc_scl.list8cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">청소년만 가능! '청소년증' 발급 방법부터 혜택까지~</strong>
						<p class="desc">​이걸 보고 있는 엘친들!누군가 친구들의 신분을 증명하라고 한다면친구들은 어떻게 할 건가요?​여러 방법이 있겠지만,그 중 학생증을 보이는 방법도 있을 거예요​그런데 이때,학교를 다니지 않는 친구들은학생증 대신 무엇을 보여줄 수 있을까요??​​​​학교를 다니든, 다니지 않든모든 청소년이 발급 받을 수 있고,​딱~ 청소년 때만! 발급 받을 수 있는한정템, 청소</p>
						<div class="source_box">
							<span class="date">1주일 전</span>
							<span class="source"><span class="source_inner">엘리트 학생복</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_4db4ab74-807f-11eb-a04a-318a5ea889f8" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30797599&amp;memberNo&#x3D;23825279" class="theme_thumb" data-clk="tcc_scl.list8cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615266096507WCQak.jpg%22&amp;type&#x3D;nf340_228" alt="돼지고기는 덜 익혀서 먹으면 정말 안 될까?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30797599&amp;memberNo&#x3D;23825279" class="theme_info" data-clk="tcc_scl.list8cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">돼지고기는 덜 익혀서 먹으면 정말 안 될까?</strong>
						<p class="desc">많은 사람이 돼지고기나 소고기를 구워 먹습니다. 구워 먹는 이유는 맛 때문이기도 하나 궁극적으로 기생충으로부터의 감염 등을 예방하기 위한 목적이 더 큽니다. 이와 관련해 소고기를 먹을 때 소고기는 살짝만 익혀 먹어도 되고, 돼지고기는 바싹 익혀 먹어야 한다는 이야기를 들어봤을 겁니다.실제 소고기를 이용한 요리 중에 얇게 썬 소고기를 팔팔 끓는 육수 물에 살</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">사물궁이 잡학지식</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_632ee78b-815a-11eb-a04a-814b1de668f8" data-da-position="true">
					<a href="https://blog.naver.com/ahdfudsl/222260414740" class="theme_thumb" data-clk="tcc_scl.list8cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0310%2Fupload_1615351812911gp3HO.jpg%22&amp;type&#x3D;nf340_228" alt="&#x27;신상 과자&#x27; 두꺼비 감자칩 &amp; 참깨 라면 타임 먹어봄!" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/ahdfudsl/222260414740" class="theme_info" data-clk="tcc_scl.list8cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">'신상 과자' 두꺼비 감자칩 & 참깨 라면 타임 먹어봄!</strong>
						<p class="desc">#gs25신상 #두꺼비감자칩 과 #신상과자 #참깨라면타임 을 사왔어요. 요즘 gs신상으로 두꺼비시리즈가 많이 보이네요. 두꺼비바, 진로안주플래터 등!​gs25신상은 이 외에도 추억의분식 시리즈 모둠세트, 가래떡떡볶이, 사라다빵, 김밥세트, 감바스알하이오, 트러플유니짜장, 매콤로제치킨파스타, 시카고치즈피자, 시카고피자오리지널, 홍어삼합, 우유크림빵, 설레임카</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">몽자킴</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_4b3a0e82-807f-11eb-a04a-19eb4dc8c3be" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30713621&amp;memberNo&#x3D;36310338" class="theme_thumb" data-clk="tcc_scl.list8cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615262963394fH8EX.jpg%22&amp;type&#x3D;nf340_228" alt="자다가 다리에 쥐가 나는 이유" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30713621&amp;memberNo&#x3D;36310338" class="theme_info" data-clk="tcc_scl.list8cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">자다가 다리에 쥐가 나는 이유</strong>
						<p class="desc">[건강쏙쏙] &#x27;야간 다리 경련&#x27; 증상의 원인과 해결법 [편집자주] 하루하루 쌓여가는 스트레스와 피로, 당신의 건강은 안녕하신가요? 머니투데이가 건강 관리에 도움이 될 알짜배기 내용들만 쏙쏙 뽑아 매주 토요일 독자들을 찾아갑니다.  /사진제공&#x3D;게티이미지뱅크 수면 중 갑작스럽게 발이나 다리에 쥐가 나는 것은 상당히 고통스러운 경험이다. 잠</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">머니투데이</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_b417ed5f-7beb-11eb-83fb-556270adfc29" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30795029&amp;memberNo&#x3D;12244919" class="theme_thumb" data-clk="tcc_scl.list8cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0303%2Fupload_16147629667088qC2u.jpg%22&amp;type&#x3D;nf340_228" alt="돌아서면 배꼽 잡는 아재 개그 모음" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30795029&amp;memberNo&#x3D;12244919" class="theme_info" data-clk="tcc_scl.list8cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">돌아서면 배꼽 잡는 아재 개그 모음</strong>
						<p class="desc">말을 못하는 시골 동네를 두 글자로 줄이면? 신데렐라가 잠을 못 자면? 포도가 자기소개 할 때 하는 말은? 미소의 반대말은? 똥 싸고 나온 물고기는? 천하장사가 타고 다니는 차는? 방바닥보다 높은 바닥은? 공원이 늙으면? 답 : 읍읍 답 : 모짜렐라 답 : 포도당 답 : 당기소 답 : 일본어 답 : 으랏차차 답 : 발바닥 답 : 팍(park)</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">한경잡앤조이</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-8" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="5"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_b417ed60-7beb-11eb-83fb-4d99b0a415e9" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30803919&amp;memberNo&#x3D;46287382" class="theme_thumb" data-clk="tcc_scl.list9cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614932750942oZWnn.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;귀여운데?&quot; 뱀들의 깜찍한 패션쇼" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30803919&amp;memberNo&#x3D;46287382" class="theme_info" data-clk="tcc_scl.list9cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"귀여운데?" 뱀들의 깜찍한 패션쇼</strong>
						<p class="desc">꼬리스토리는 단 한 번도 뱀이 귀엽다는 생각을 해본 적이 없습니다. 그런데 그동안 너무 편협한 생각을 가지고 있었는지도 모르겠다는 반성을 했는데요.소셜 커뮤니티 레딧의 &#x27;모자 쓴 뱀들&#x27;이라는 게시판을 보면서 느낀 생각입니다.01. 자 갑니다 가요 &#x27;부르셨나요?&#x27;이불 속에서 자던 뱀이 보호자의 기척을 느끼고 얼굴을 빼꼼- 내밀었습니다.세상에. 뱀도 이렇게 귀</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">꼬리스토리</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_27a4073a-8067-11eb-a04a-673d39d0fb74" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30801341&amp;memberNo&#x3D;2451715&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list9cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615255149502ajw8T.jpg%22&amp;type&#x3D;nf340_228" alt="세상에서 가장 먼저 탄생한 생물은?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30801341&amp;memberNo&#x3D;2451715&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list9cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">세상에서 가장 먼저 탄생한 생물은?</strong>
						<p class="desc">『과학 개념 연구소 1』 다음 이야기 한 살짜리 강아지가 새끼를 낳는다고? 다음 이야기는 03월 02일 화요일날 연재됩니다:)호기심을 따라 탐험하면서 신나게 과학을 배워봐요! 초등 전 학년 과학 교과서 개념 100% 수록! 『과학 개념 연구소 1』 1화부터 8화까지 댓글 남기기 이벤트가 진행 중입니다-★ 꾸준히 댓글을 남겨주신 6분께 「과학 개념 연</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">비룡소</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_a1eed614-7cb9-11eb-a04a-692b916bc832" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30777864&amp;memberNo&#x3D;799097" class="theme_thumb" data-clk="tcc_scl.list9cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614929905333Q2mcg.jpg%22&amp;type&#x3D;nf340_228" alt="90% 나를 망치는 최악의 스트레스 대처법" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30777864&amp;memberNo&#x3D;799097" class="theme_info" data-clk="tcc_scl.list9cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">90% 나를 망치는 최악의 스트레스 대처법</strong>
						<p class="desc">1일 1명상 1평온“나에게 고요해질 시간을 허락하세요.” 명상을 처음 시작하는 당신을 위한 30일 명상 수업1. 해당 콘텐츠는 &lt;1일 1명상 1평온&gt;을 바탕으로 제작한 콘텐츠입니다. 2. 공감되었다면 ♥좋아요♥ 를 눌러주세요. 3. 삶을 풍요롭게 하는 더 많은 정보를 얻고 싶다면 카시오페아 포스트 팔</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">카시오페아</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_a56d0058-7cb9-11eb-a04a-ff6511d468c4" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30775763&amp;memberNo&#x3D;12374975" class="theme_thumb" data-clk="tcc_scl.list9cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614930599531TFvjl.jpg%22&amp;type&#x3D;nf340_228" alt="다른 나라 음식 아님!
한국이 원조인 음식들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30775763&amp;memberNo&#x3D;12374975" class="theme_info" data-clk="tcc_scl.list9cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">다른 나라 음식 아님!
한국이 원조인 음식들</strong>
						<p class="desc">사진을 클릭하시면 더 선명하고다양한 카드뉴스를 즐기실 수 있습니다.물 건너온 음식?물 건너간 음식!뭔가 외국음식 같은 느낌에먹으면서도 ‘다른나라 음식이겠거니’ 했었던 음식들오히려 외국인들이 더 잘 아는,의외로 한국원조 음식들어떤 것들이 있을까요?  캡틴 코리아 &#x27;태극기&#x27; 등장!...마블에 한국인 슈퍼히어로들이 있다 [BY 아시아투데이] 사진을</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">아시아투데이</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_a56d0057-7cb9-11eb-a04a-853e7e38828b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30753125&amp;memberNo&#x3D;51907070" class="theme_thumb" data-clk="tcc_scl.list9cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614931164110Zg7mn.jpg%22&amp;type&#x3D;nf340_228" alt="플라스틱 콜라병, 종이 병으로 바뀐다고?!" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30753125&amp;memberNo&#x3D;51907070" class="theme_info" data-clk="tcc_scl.list9cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">플라스틱 콜라병, 종이 병으로 바뀐다고?!</strong>
						<p class="desc">동영상  버튼을 누르면 현재 화면에서 재생됩니다. 플라스틱 페트병 대신 종이 병에 콜라를? 이게 가능해? ｜크랩 #크랩 #플라스틱 #코카콜라전 세계 플라스틱 소비량 1위라는 오명을 가진 코카콜라가 플라스틱 페트병을 대체할 종이 병 시제품을 최근 공개했습니다. 코카콜라의 과일음료 ‘아데즈’는 올 여름 헝가리에서 종이 병에 담겨 판매될 예정입니다. 한편, 칼스</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">KLAB</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-9" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="5"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_c3225b36-7c92-11eb-a785-c5e411f24c55" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30747764&amp;memberNo&#x3D;22846622" class="theme_thumb" data-clk="tcc_scl.list10cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614836046770AQkEj.jpg%22&amp;type&#x3D;nf340_228" alt="알아두면 유용한 채팅용 영어 줄임말" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30747764&amp;memberNo&#x3D;22846622" class="theme_info" data-clk="tcc_scl.list10cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">알아두면 유용한 채팅용 영어 줄임말</strong>
						<p class="desc">#1 알아두면 유용한 채팅용 영어 줄임말 #2 1. MSG &#x3D; message 메시지 2. u &#x3D; you 너 3. r &#x3D; are 4. ur &#x3D; your 너의 5. u r &#x3D; you are 6. 4 &#x3D; for ~를 위해 7. dnt &#x3D; don&#x27;t 8. plz &#x3D; please 제발 9. cuz &#x3D; because 때문에 10. yw &#x3D; you&#x27;re welcome </p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">비주얼다이브</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_a1eed615-7cb9-11eb-a04a-7f06b3a088ab" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30678406&amp;memberNo&#x3D;11195360" class="theme_thumb" data-clk="tcc_scl.list10cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614930075927HK04q.jpg%22&amp;type&#x3D;nf340_228" alt="생리통을 악화시키는 자세 4가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30678406&amp;memberNo&#x3D;11195360" class="theme_info" data-clk="tcc_scl.list10cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">생리통을 악화시키는 자세 4가지</strong>
						<p class="desc">가임기 여성의 절반이 경험한다는 생리통, 느닷없이 찾아오는 통증에 일상생활까지 어려움을 겪곤 하는데요. 단순히 아랫배 통증뿐 아니라 허리, 엉치, 골반 등에도 통증이 나타나고 심한 경우 설사, 두통, 구토, 우울감, 피로감 등이 동반되기도 합니다. 생리통은 특별한 원인 질환 없이 나타나는 ‘일차성 생리통’인 경우가 대부분인데요. 이는 배란 활동과 함께 프로</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">자생한방병원</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_2547c7b9-8067-11eb-a04a-5d6ee227c967" data-da-position="true">
					<a href="https://blog.naver.com/samsungfund/222227514692" class="theme_thumb" data-clk="tcc_scl.list10cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0309%2Fupload_1615254941234U2Cq5.jpg%22&amp;type&#x3D;nf340_228" alt="은행출납사무원이 되려면 어떤 능력이 있어야 할까" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://blog.naver.com/samsungfund/222227514692" class="theme_info" data-clk="tcc_scl.list10cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">은행출납사무원이 되려면 어떤 능력이 있어야 할까</strong>
						<p class="desc">[금융직업] 은행의 얼굴,은행출납사무원은행에 방문해 본 친구들이 있나요?​은행은&#x27;금융백화점&#x27;이라고 불릴 만큼입금, 출금, 환전, 대출 등굉장히 다양한 금융 업무를해결할 수 있어요.우리가 금융 업무를 잘 볼 수 있도록은행에는 &#x27;이 직업&#x27;을가진 사람이 있습니다.​&#x27;은행원&#x27;이라고도불리는데요.오늘은 은행의 얼굴,은행출납사무원에 대해알아...</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">착한예삐</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_c0bdde6f-7c92-11eb-83fb-0ff39ca3ca9b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30805563&amp;memberNo&#x3D;2420267" class="theme_thumb" data-clk="tcc_scl.list10cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_16148356836363c3qU.jpg%22&amp;type&#x3D;nf340_228" alt="집에서도 할 수 있는 봉사 4가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30805563&amp;memberNo&#x3D;2420267" class="theme_info" data-clk="tcc_scl.list10cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">집에서도 할 수 있는 봉사 4가지</strong>
						<p class="desc">여러분 혹시 사랑의열매 아시나요? 대한민국 국민이라면 누구나 다 아는 열매뱃지의 상징인 사회복지공동모금회요! 사랑의열매는 지난해 12월 1일부터 올해 1월 31일까지 연말연시 기부캠페인 ‘희망 2021 나눔캠페인’을 진행했다고 해요. 사랑의열매는 이 캠페인을 통해 총 4천 9억원을 모금했다고 최근 밝혔어요. ‘희망 2021 </p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">시사원정대</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_c3225b35-7c92-11eb-a785-a1970d819f5a" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30786003&amp;memberNo&#x3D;953257&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list10cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614835778292bsyMO.jpg%22&amp;type&#x3D;nf340_228" alt="영어 문법과 영작이 탄탄해지는 5형식 문장 만들기" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30786003&amp;memberNo&#x3D;953257&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list10cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">영어 문법과 영작이 탄탄해지는 5형식 문장 만들기</strong>
						<p class="desc">모든 영어 문장은 우리가 알고 있는 5형식 안에서 만들어집니다. 아무리 긴 영어 문장도 주어와 동사만 발견해도 문장의 구조를 이미 좁힌 것이나 다름없습니다. 영어 지문이 점차 길어지는 초등 4, 5, 6학년에게 &#x27;5형식 문장&#x27;은 매우 유용한 학습 도구가 됩니다. 짧은 단문 영작과 영어 문법 이해에 도움이 되죠. 꾸준한 읽기 쓰기 연습을 통해 전반적인 영어 </p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">길벗스쿨</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-10" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="6"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_a1eed616-7cb9-11eb-a04a-25e0e0ae83d0" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30810674&amp;memberNo&#x3D;37655020" class="theme_thumb" data-clk="tcc_scl.list11cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614929758010iTP5j.jpg%22&amp;type&#x3D;nf340_228" alt="앞으로 주목해야 할 &#x27;싱어송라이터&#x27; 아이돌들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30810674&amp;memberNo&#x3D;37655020" class="theme_info" data-clk="tcc_scl.list11cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">앞으로 주목해야 할 '싱어송라이터' 아이돌들</strong>
						<p class="desc">본업도 잘하는데, 그 노래를 직접 만들어 프로듀싱까지 하는 아이돌이 있다? 앞으로의 행보가 기대되는 ‘싱어송라이터’ 능력치 만렙 아이돌을 뽑아봤다.(여자)아이들 전소연(여자)아이들의 리더이자 메인 래퍼를 담당하고 있는 전소연. 무려 취미이자 특기가 작사라고 한다! 이미 그녀의 놀라운 프로듀싱 능력은 수많은 </p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">겟꿀</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_a1eed613-7cb9-11eb-a04a-c1e0bf9b45e5" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30589242&amp;memberNo&#x3D;34921815" class="theme_thumb" data-clk="tcc_scl.list11cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0305%2Fupload_1614930307956Cx2cN.jpg%22&amp;type&#x3D;nf340_228" alt="수학으로 사람을 살리기도 했다?!" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30589242&amp;memberNo&#x3D;34921815" class="theme_info" data-clk="tcc_scl.list11cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">수학으로 사람을 살리기도 했다?!</strong>
						<p class="desc">&lt;EBS 대도서관 잡(JOB)쇼&gt; 수학자 박형주 편 (2017.03.31 방영 / EBS2TV)알쏭달쏭 머리 아픈 수학 공식! 많은 학생들이 수학 과목을 어려워할 것 같아요. 포기하고 싶은 수학이지만, 논리적 사고를 위한 중요한 학문이라고 모두가 입을 모아 말해요. 오늘은 수학자 박형주 박사가 수학의 새로운 세계를 소</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">스쿨잼</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_7b099b69-7fd9-11eb-83fb-6d3d2d7a2c9d" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30733058&amp;memberNo&#x3D;39207624" class="theme_thumb" data-clk="tcc_scl.list11cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0308%2Fupload_1615185738006MUrwO.jpg%22&amp;type&#x3D;nf340_228" alt="차에 낙서한 딸을 아빠가 혼낼 수 없었던 이유" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30733058&amp;memberNo&#x3D;39207624" class="theme_info" data-clk="tcc_scl.list11cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">차에 낙서한 딸을 아빠가 혼낼 수 없었던 이유</strong>
						<p class="desc">마당으로 나간 아빠는 경악을 금치 못했다. 분명 어제까지만 해도 깨끗했던 차 여기저기에 낙서가 그려져 있었던 것. 범인은 바로 검은색 매직을 손에 든 채 자신을 향해 배시시 웃는 9살 된 딸이었다. 그런데 아빠는 딸이 저지른 짓 때문에 화가 난 게 아니라, 오히려 낙서를 보며 감탄을 하고 말았다.최근 온라인 미디어 레드칠리21은 말레이시아에 사는 아하마드 </p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">NTD Korea</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_7b099b6a-7fd9-11eb-83fb-451dbddf08b3" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30745117&amp;memberNo&#x3D;29949587&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list11cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0308%2Fupload_1615185744793DCSOB.jpg%22&amp;type&#x3D;nf340_228" alt="&#x27;한복 교복 어떻냐&#x27;는 질문에 10대들의 반응은?" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30745117&amp;memberNo&#x3D;29949587&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list11cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">'한복 교복 어떻냐'는 질문에 10대들의 반응은?</strong>
						<p class="desc">[인사이트] 김소영 기자 &#x3D; &quot;올해부터 이 한복 교복 입으면 어때?&quot;이 같은 질문에 많은 10대 학생들의 의견이 갈렸다. 자신들이 직접 교복을 입어야 하는 입장인 만큼 실질적인 문제점을 비판하는 목소리가 돋보였다.최근 각종 온라인 커뮤니티에는 &#x27;한복 교복 착용 샷&#x27;이라는 제목으로 다양한 사진이 올라왔다. 해당 사진은 지난 2020년 유튜브 채널 &#x27;한복진흥센</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">인사이트</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_7b099b6b-7fd9-11eb-83fb-7b46c97b9d4b" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30735169&amp;memberNo&#x3D;339226" class="theme_thumb" data-clk="tcc_scl.list11cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0308%2Fupload_16151857502965nWj2.jpg%22&amp;type&#x3D;nf340_228" alt="먹는 거 아님! 맛있는 음식처럼 생긴 착시 사진들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30735169&amp;memberNo&#x3D;339226" class="theme_info" data-clk="tcc_scl.list11cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">먹는 거 아님! 맛있는 음식처럼 생긴 착시 사진들</strong>
						<p class="desc">Forbidden Snacks레딧의 커뮤니티 &#x27;r/ForbiddenSnacks&#x27;는 이색적인 사진들을 공개하고 있어 화제를 모았다. 이들은 맛있는 음식처럼 보이지만, 실제로는 먹을 수 없는 흥미로운 것들의 사진을 인터넷에 선보이고 있어 보는 이들의 이목을 집중시켰다.&#x27;r/ForbiddenSnacks&#x27;에서 공개하고 있는 사진에서는 시각적 착시를 불러일으키는 물</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">아이디어 래빗</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>
<div class="group_theme" data-block-id="" data-block-code="PC-THEME-SCHOOL-MOBILE-RANKING-DEFAULT-11" data-block-type="MATERIALS" data-template-code="MOBILE-RANKING-LIST"

	 data-da="container"
	 data-index=""
     data-page="6"
	 style="display:none">

	<div class="list_theme_wrap">
		<ul class="list_theme">

				<li class="theme_item" data-gdid="CAS_7b099b6c-7fd9-11eb-83fb-6b08ec8c617c" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30775127&amp;memberNo&#x3D;24216069&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list12cont1" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0308%2Fupload_1615185756126yLbQF.jpg%22&amp;type&#x3D;nf340_228" alt="옛날이랑 똑같네! 어릴 적 사진 그대로 따라 한 스타들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30775127&amp;memberNo&#x3D;24216069&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list12cont1" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">옛날이랑 똑같네! 어릴 적 사진 그대로 따라 한 스타들</strong>
						<p class="desc">과거로 돌아간 스타 어릴 적 사진을 따라 하는 게 유행이다. 스타들 역시 이러한 흐름을 놓치지 않고 인증에 동참했다. 개인 SNS부터 뮤직비디오까지 다양한 콘텐츠를 통해 자신의 과거와 현재를 비교한 스타들을 소개한다. m.thesingle.co.kr 과거로 돌아간 스타어릴 적 사진을 따라 하는 게 유행이다. 스타들 역시 이러한 흐름을 놓치지 않고 인증에 동</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">싱글즈</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_baea0453-7c92-11eb-83fb-85bb837d4cdf" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30779476&amp;memberNo&#x3D;339226" class="theme_thumb" data-clk="tcc_scl.list12cont2" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614826541001OOk0T.jpg%22&amp;type&#x3D;nf340_228" alt="&quot;이렇게요?&quot; 포토샵 장인의 엉뚱한 사진 편집" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30779476&amp;memberNo&#x3D;339226" class="theme_info" data-clk="tcc_scl.list12cont2" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">"이렇게요?" 포토샵 장인의 엉뚱한 사진 편집</strong>
						<p class="desc">Photoshop Artist James Fridman[아이디어 래빗] &#x27;James Fridman&#x27;은 온라인상에서 가장 유명한 포토샵 사진 편집사 중 한 명이다. 그는 사람들이 요청하는 요구에 맞춰 완벽하게 사진을 편집해 많은 인기를 얻고 있다.재미있게도 편집사의 사진은 조금 이색적인 모습을 가지고 있는 것이 특징이다. 사람들의 요청을 문자 그대로 해석해 </p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">아이디어 래빗</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_bc3e70c6-7c92-11eb-83fb-2de2085f6c21" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30782403&amp;memberNo&#x3D;25840789" class="theme_thumb" data-clk="tcc_scl.list12cont3" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614834701842Sfn3W.jpg%22&amp;type&#x3D;nf340_228" alt="정말 이렇게 잔다고? 신기한 잠버릇을 가진 아이돌들" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30782403&amp;memberNo&#x3D;25840789" class="theme_info" data-clk="tcc_scl.list12cont3" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">정말 이렇게 잔다고? 신기한 잠버릇을 가진 아이돌들</strong>
						<p class="desc">TV에 보이는 아이돌의 이미지는 예쁘고 멋짐 그 자체인데요. 이외로 이런 아이돌 중에 잠버릇이 고약해서 주변을 깜짝 놀래키는 멤버들이 있다고 하네요. 주변 멤버들이 함께 자는 것을 피하거나 무섭다고 말하기까지 한다고 하는데요. 도대체 어떤 잠버릇을 가지고 있길래 그럴까요? 출처 : 정은지 인스타그램 정은지는 방송에서 몽유병 증상이 있다고 밝혔는데요. 실제로</p>
						<div class="source_box">
							<span class="date">2주일 전</span>
							<span class="source"><span class="source_inner">치어풀24</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_bfa9d65d-7c92-11eb-83fb-c75df6c68b88" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30680581&amp;memberNo&#x3D;37966086&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list12cont4" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614835211290jR5ug.jpg%22&amp;type&#x3D;nf340_228" alt="벽만 있으면 할 수 있는 운동 5가지" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30680581&amp;memberNo&#x3D;37966086&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list12cont4" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">벽만 있으면 할 수 있는 운동 5가지</strong>
						<p class="desc">설 전후 집에서 머무는 시간이 더 많아진다. 음식을 많이 먹게 되는 명절이니, 집콕운동(홈트)으로 잉여 칼로리를 소모하는 게 좋겠다. 아주 잠깐이라도 틈을 내 운동을 하자. 거실이나 방의 벽면을 조금만 이용해도 할 수 있는 운동이 있다. 10초씩만 해도 운동효과를 볼 수 있다.  동영상  버튼을 누르면 현재 화면에서 재생됩니다. 벽을 이용해 근력 키우는 홈</p>
						<div class="source_box">
							<span class="date">1개월 전</span>
							<span class="source"><span class="source_inner">캔서앤서</span></span>
						</div>
					</a>
				</li>

				<li class="theme_item" data-gdid="CAS_baea0454-7c92-11eb-83fb-7d0f7bb713ad" data-da-position="true">
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30757013&amp;memberNo&#x3D;1192430&amp;navigationType&#x3D;push" class="theme_thumb" data-clk="tcc_scl.list12cont5" target="_blank">
						<img  data-src="https://s.pstatic.net/dthumb.phinf/?src&#x3D;%22https%3A%2F%2Fs.pstatic.net%2Fstatic%2Fwww%2Fmobile%2Fedit%2F2021%2F0304%2Fupload_1614826744138Ja4I1.jpg%22&amp;type&#x3D;nf340_228" alt="자세를 통해 알 수 있는 4가지 성격 유형" width="170" height="114">
						<span class="thumb_bd"></span>
					</a>
					<a href="https://post.naver.com/viewer/postView.nhn?volumeNo&#x3D;30757013&amp;memberNo&#x3D;1192430&amp;navigationType&#x3D;push" class="theme_info" data-clk="tcc_scl.list12cont5" target="_blank">
						<em class="theme_category"> 스쿨잼</em>
						<strong class="title elss">자세를 통해 알 수 있는 4가지 성격 유형</strong>
						<p class="desc">“단 몇 초 만에 상대를 파악할 수 있다!성격 분석 전문가가 알려주는 인간관계의 기술”『인간 관찰』▶ https://bit.ly/3baaQhz    인간 관찰 book.naver.com</p>
						<div class="source_box">
							<span class="date">3주일 전</span>
							<span class="source"><span class="source_inner">쌤앤파커스</span></span>
						</div>
					</a>
				</li>

		</ul>
	</div>
</div>


	<p class="alert_msg" data-clk-prefix="tcc_scl">스쿨잼판의 컨텐츠는 <a href="https://blog.naver.com/naverschool/220966254204" data-clk-suffix="corp" target="_blank">㈜스쿨잼</a>에 의해 운영·편집 됩니다.</p>



	<div class="btn_more_wrap">
		<button type="button" class="btn_more" data-clk-custom="tcc_scl.more" data-next-page="2"><i class="ico_more"></i>새로운 글 더보기</button>
	</div>


	</div>
</div>
 </div> </div> <div id="NM_INT_RIGHT" class="column_right"> <div class="column_fix_wrap"> <div id="da_brand"></div>




<div id="account" class="sc_login">
<h2 class="blind">로그인</h2>
<p class="login_msg">네이버를 더 안전하고 편리하게 이용하세요</p>
<a href="https://nid.naver.com/nidlogin.login?mode=form&url=https%3A%2F%2Fwww.naver.com" class="link_login" data-clk="log_off.login"><i class="ico_naver"><span class="blind">네이버</span></i>로그인</a>
<div class="sub_area">
<div class="look_box">
<a href="https://nid.naver.com/user/help.nhn?todo=idinquiry" class="link_look" data-clk="log_off.searchid">아이디</a>
<a href="https://nid.naver.com/nidreminder.form" class="link_look" data-clk="log_off.searchpass">비밀번호찾기</a>
</div>
<a href="https://nid.naver.com/nidregister.form?url=https%3A%2F%2Fwww.naver.com" class="link_join" data-clk="log_off.registration">회원가입</a>
</div>
</div>



 <div id="timesquare" class="sc_timesquare"> <h2 class="blind">타임스퀘어</h2> <div class="card_wrap">
<div class="card_nav">
<a href="#" role="button" class="btn_nav btn_prev" data-clk="squ.pre"><span class="blind">이전</span></a>
<a href="#" role="button" class="btn_nav btn_next" data-clk="squ.next"><span class="blind">다음</span></a>
</div>
<div id="NM_TS_ROLLING_WRAP" style="height: 100%;">
<div>
<a href="https://search.naver.com/search.naver?sm=top_hty&amp;fbm=0&amp;ie=utf8&amp;query=%EC%BD%94%EB%A1%9C%EB%82%9819" class="card_news" data-clk="squ.line3"><i class="news_badge">이슈</i><span class="news">코로나바이러스감염증19 현황</span></a>
</div>
<div>
<a href="https://finance.naver.com/sise/sise_index.nhn?code=KOSPI" class="card_stock " data-clk="squ.kospi">
<strong class="stock_title">증시</strong>
<div class="stock_box">
<em class="name">코스피</em>
<strong class="current">3,047.50</strong>
<span class="rate rate_down">19.67 -0.64%</span>
</div>
</a>
</div>
<div>
<a href="https://finance.naver.com/sise/sise_index.nhn?code=KOSDAQ" class="card_stock " data-clk="squ.kosdaq">
<strong class="stock_title">증시</strong>
<div class="stock_box">
<em class="name">코스닥</em>
<strong class="current">943.78</strong>
<span class="rate rate_up">3.13 +0.33%</span>
</div>
</a>
</div>
<div>
<a href="https://finance.naver.com/marketindex/exchangeDetail.nhn?marketindexCd=FX_USDKRW" class="card_stock type_exchange" data-clk="squ.usd">
<strong class="stock_title">환율</strong>
<div class="stock_box">
<em class="name">USD</em>
<strong class="current">1,130.30</strong>
<span class="rate rate_down">0.20 -0.02%</span>
</div>
</a>
</div>
</div>
</div> <!-- EMPTY --> </div>  <div id="veta_branding"> <iframe id="da_iframe_rolling" name="da_iframe_rolling" data-iframe-src="https://siape.veta.naver.com/fxshow?su=SU10601&amp;nrefreshx=0" data-veta-preview="main_rolling" title="광고" width="350" height="200" marginheight="0" marginwidth="0" scrolling="no" frameborder="0"></iframe> <span class="veta_bd_t"></span> <span class="veta_bd_b"></span> <span class="veta_bd_l"></span> <span class="veta_bd_r"></span> </div>   <div id="shopcast" class="sc_shopcast"> <iframe id="shopcast_iframe" data-iframe-src="https://castbox.shopping.naver.com/shoppingboxnew/main.nhn" title="쇼핑캐스트" width="350" height="1539" marginheight="0" marginwidth="0" scrolling="no" frameborder="0"></iframe> </div> </div> </div> <a id="NM_scroll_top_btn" href="#wrap" class="content_top"><span class="blind">TOP</span></a> <button id="NM_darkmode_btn" type="button" role="button" class="btn_theme" aria-pressed="false"  > <span class="blind">라이트 모드로 보기</span> </button> </div> <div id="footer" role="contentinfo"> <div class="footer_inner"> <div class="banner_area"> <div class="da_box_wrap">    <div id="da_public_left"> <iframe id="da_iframe_bottom_left" data-iframe-src="https://siape.veta.naver.com/fxshow?su=SU10641&amp;nrefreshx=0" title="광고" width="350" height="86" scrolling="no" frameborder="0"></iframe> </div> <div id="da_public_right"> <iframe id="da_iframe_bottom_right" data-iframe-src="https://siape.veta.naver.com/fxshow?su=SU10642&amp;nrefreshx=0" title="광고" width="350" height="86" scrolling="no" frameborder="0"></iframe> </div> <div id="veta_time2"> <iframe id="da_iframe_below" name="da_iframe_below" data-iframe-src="https://siape.veta.naver.com/fxshow?su=SU10640&amp;nrefreshx=0" data-veta-preview="main_below" width="350" height="86" scrolling="no" frameborder="0" title="광고"> </iframe> </div> </div> </div> <div class="notice_area" data-clk-prefix="ntc"> <div class="notice_box"> <h3 class="title"><a href="https://www.naver.com/NOTICE">공지사항</a> </h3> <!-- EMPTY --> </div> <a href="more.html" class="link_all" data-clk="svcmap">서비스 전체보기</a> </div> <div class="aside_area"> <div class="partner_box_wrap"> <div class="partner_box" data-clk-prefix="crt"> <h3 class="title">Creators</h3> <a href="https://www.navercorp.com/service/creators" class="link_partner" data-clk="creator">크리에이터</a> <a href="https://www.navercorp.com/service/business" class="link_partner" data-clk="smbusiness">스몰비즈니스</a> </div> <div class="partner_box" data-clk-prefix="crt"> <h3 class="title">Partners</h3> <a href="https://business.naver.com/service.html" class="link_partner" data-clk="service">비즈니스 · 광고</a> <a href="https://sell.storefarm.naver.com/#/home/about" class="link_partner" data-clk="store">스토어 개설</a> <a href="https://smartplace.naver.com" class="link_partner" data-clk="place">지역업체 등록</a> <a href="https://expert.naver.com/expert/introduction?tab=guide#join" class="link_partner" data-clk="expert">엑스퍼트 등록</a> </div> <div class="partner_box" data-clk-prefix="crt"> <h3 class="title">Developers</h3> <a href="https://developers.naver.com" class="link_partner" data-clk="center">네이버 개발자 센터</a> <a href="https://developers.naver.com/docs/common/openapiguide/#/apilist.md" class="link_partner" data-clk="openapi">오픈 API</a> <a href="https://naver.github.io" class="link_partner" data-clk="opensource">오픈소스</a> <a href="https://d2.naver.com" class="link_partner" data-clk="d2">네이버 D2</a> <a href="http://d2startup.com" class="link_partner" data-clk="naverD2SF">네이버 D2SF</a> <a href="https://www.naverlabs.com" class="link_partner" data-clk="labs">네이버 랩스</a> </div> </div> <div class="service_box_wrap"> <div class="service_box" data-clk-prefix="wbd"> <a href="http://whale.naver.com/" class="service_logo" data-clk="bt"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAMAAADVRocKAAAC91BMVEUAAACE1dAbf6jE1Nq/z9e82drQ3OG7ytOzws+6x9QNs7MeLpQSx60QrLAfL50gMakTxKyzwc8fMacSr6yywc8fMKIdLYzJ1d4KrrW6ydMJrrUbr6QgMKW2xNEcr6W7ydUfL5cIr7XBztgMtbMeL50fMaQQzrI0tK4cLIQUvqsVvqofMKLL0eGzxM+4xtIZuKcJr7XCyNt0xsILsLW1w9AdLYZwvL8gMaoeLY6CzMceLYyxz9fI1d0JwLMeLY4KrbXFzeAgMqvN2OEIrLUGsrVIurMfLpAcLIIIsbVWs7MeLpXIzt0UvakgMqwfL5x4wcEJsLYfMagWt6k6qqoil6DV2+UdK4EeMoEfLpOzws4/s7YgMacXvqoC27QcK38B17TE1dobKW0bKnID0bTP3OACzrQcKngcLIMbKXAD07QeLYfi6uzY4+YfLpDN2+DK2d0cK3zU4eTS3+IFzLQeL5ccKnXk7O7G19wgMJ3R3uHa5ejL2t7c5unI2Nzg6esBxrMfMKPp7vEeLYrr8fMNr7X2+PkeLYzt8vQE2LTx9fYfLpPz9/gHyLMOsrUHr7UCybQLs7YKu7UIuLUFvLQGwbUIxbQGw7QcKnTZ5OfV4uUJv67e5+rd5+rl7e8Ju6z3+vvm7vDp8PHs8vPw9fbv9PUgMaj6/PwgMqwJs6kNw7AFubULtrUGtbUJvrQEv7QAwq8MrqYKuKsKtqn+/v4Osaf7/P0K1rMHq6UeqKQNqKQhNoIgSH0Vvqoie5MhWIdV3cAcsaYhhZoglJkdLXnJ7+ia5tU61rgp1rceoKIhb4whZYgcM3fj9vJw3sdJx7xtd6sXt6hCT5AvPpAfPYQbKIMcJ34fP3q+8uSy49ux0tWd2NKYzM+A48yE08t6xchdv8FP0b1zfbcSpKIgToEbJ3nE5OG12Nmn19WM5tGKk8ehqMZlxcJJuLwgtLcbvbYc2bUTtaknNpA1Q4bZ7uuzuNuP3M9p0cNfbLUKtq5IVqk8Sp8jZpxaZZrUCA9eAAAAXXRSTlMABAj99BcO6IpfLhj9hPLp5ryyq6ZzXDnd2cuYkHtzbFFOQj0yJv76+ebc29fXx8TCuJuVlIqHgX5gPS0kEvn49/f08O3t6+fj2tLR0MzGeGNfWvbz7sXBpYN4PB4CDkIdAAAFcUlEQVRo3q3TdVwTYRjA8eeI0SKgYnd3d3d362tgO7u7Y4rd3d2K4pwwQkAQJUSxu7vbPzwYg9vufe+eO/neP9vtPr/n7t53gFMobxXPVu719pu4t/LM2a4gBwioeGZP9/0U9TyrFEyHepUSeyW45+wB/8GmXetZskpkdlGbz+w+CyVDThdV+QyT0FSMyFtikiIZMnOggIvnOMWaFwS0LBkkQj/q/mL8UpVDvv2ui6V89XvF+qm1C2rnNx8u6ferq8zfGlcHWdUbD/8PtbPI7p7aC5R49Mn6TFWZ5Z2jzKNPolOVJPtD04HEhLxFh6YH5lsqWHQQ1dVBCjFW2qUJo+8Xq3BAUeputenci27Qo6u9FGpC+8dV6pUODAZDQkKCwdAFRNz+s2wMiYwbQkwi7oWVBCvOHUep9yQkTkfMIsIv+/HygKVigaPoYuMFX+InGEQXJIS4kjRBN/b5JZutAaHcxDhQ3gVD7AWrU0a9TpgPO5OqnMUOciWJA9O8jh+IYwwmAhE39gnMrwFpchByQXCjn/kvCOf1ROil7z4LgnWuVZiQ8UpFh/gTgYs3tlvzFj4AiVbYN7oSoaDL20VaQAou6drE9UpcCCUWruyeL+ZbM3UL8Yw+YrHD4n2ozgdY9X3n05g3UnHCC6R0Xvv9pfaj/ImFoN3zqbQcJOlJkugpofWfafnoSGIp4rIvg5N5iXn+0aIS7vUQ/zBfFtMyFyPJogajXOpHrIQvYprNJf0JiEkAJu8TQqwF7VnE5mTaQyaX5PvRwUQkbLeEpH1UhqRw9ZHrP3ElInf3SOkEABmJWWhfaVG9iciHywulzNWAjY6kuiSV9wklFOELpeWHAsINZ2T3+d1JcXHrLmkVITcRGMJ8hsDehCZ8rozSkINYCKTmn8QRQn8AuQElwYtYCj4vyieG6gjdy51y6kMZYkUXmmj58kP9CcOHL7PlaKElEdEFR5031wPjCNvd2fKgOKHqF6CP1AeI7j1k+PA/aSfDdsiDjESBgDm8SJIiaCuCsgH6a7xAkuLmBASFA67zzAMuanEDdAoUHvX06dNgncldLQYU763Ex6hLkebPz7TaCfIHtOyt0kMtCpRROyAc1R8GXvy1Q1Qc/htmYNQFtyHqXEH1N2eD9ioH3NyM4gHO/VSJ2IKTC7ixqgZ8m4bjDVBMTb/waFx/IwfgNUCFK1NwHACgvZoBN5EDMgGAzRJWZSyz/3ADkjfwGo1V7PYwnPoc8MovZ2Dll18cjRzgAUnsDy5hYE24NwwpPyRrNJNuOcOSZxtx7MCk2kG6JQzfRyM5Qooix2lmsjxH9qdqIEX5TTRrGR6OQcoEZlwRSp/5BC/GjEYdI+whVfltYgfX0sXgH0CgiKh/fB3D7ck4thoQqHbS2kFGP2YyUi6w0OyUpW1rGG73x3HgwIJ98AGhU0cZ/Rhkf2oNsNLGYsC2YwwvkAMcQaTZ6TQfjzK8QfazcSDCdTiRajXD++cjUOzsgaKG3tz/uZLhHq4/PT9QVTt3NtmB1QwxI3EDnIChzeNzvLMrGd7fmoriCEyVH/P9Qyx3cP2KAJITDq9iuD8SxREkdT/C6j+Yjup3A0nOTQ8zPJiIyds6gaQCDY8wvJk4HcHOGyS1XbqC4f50jNL2IMWmwlKGd3cmItjmknn92VcwvL2F6ZeqKX37bszbv98HwU5mdfNlncfw4FYf3kSpg887aqQ3T1lW/u2dPnLk8/nKLmMoW9nDVjZfyomTzjdl1BtWcAYA+zylpGY4ONYEOc5u2evMs5a1QoHU+9I4ZXKwpcU98tgDDufc1s0re9YGdZYta5A1u5dbvlpgReOdp6JHNgc7fpCtnUO20ply5UfG/wEFXaai/lOVTwAAAABJRU5ErkJggg==" alt="웨일" width="48" height="48"> </a> <div class="service_info"> <strong class="title">웨일 브라우저</strong> <a href="http://whale.naver.com/" class="dsc" data-clk="bt">다운받기</a> </div> </div> <div class="service_box" data-clk-prefix="prj"> <a href="https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8%EA%BD%83" class="service_logo" data-clk="link"> <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAABkCAMAAAA47XeXAAAAgVBMVEUAAADN5PdGm99Gm99Gm99Gm99Gm95Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gm99Gmt9Gm99Gm99Gm99Gm95Gm99Gm99Gm95Gm99Hm99Gm99Gm9/////3+/5cp+LO5PfR5/fO5fdcp+P7/f/zv5GhAAAAInRSTlMA/v7vH9u5qJNgGwb6l8a9uqF9WFUyLxYMCtbVmLCwe4OCj8gzEgAAA0NJREFUaN7NmmFz4iAQhkkwMTHGWrWtWvWuq8mF+/8/8Ey2nb0OhSwQZnw+MHQ7pbjAy2s2gsuiLPJMLpcyy4tyISZltnmHbxw3MzEVr/MUNNL5q5iCt2ccXCN9fhPB7CQYkTsRRlWDlboSAexzGCHfC28OKxhldfDOzBMwePLNTw0sauHFFphshQcLCUwkaQRfXYBPSkrEUBdv3jezcXXhw1ciUhc+fCUidQlH7qzqEk5d2dQlnHxvU5dwVgdXdSGclaiGyamt6hLO1qIu4ZASzcFE092SBprk1jagulvXAAw/qb5N7m176xQYmOPoLymYaK/X65/PNhlagE6LGUhfRM8FjNzuf/73//bHmInzoJEpjMyeWpp9RzGz/PT6+QvMNO2Q+67PPeYZY5h7jDVg5OM+/BGikd13JfDAj/Ad1WLMyEyUwKPT00ypN1GKAljQJtFiFgqRe86eYhbWIvPPPR5d+9pKiIgUwKNJdHXBvW9jyRye1EWLWYfnJcd141Byspizz7gbUyWDuqiW0v15D9g3ZgF86JwyKUgUHJaATUmS5rsEdkkTZLjZS8Alw+skFr8Nl6H6uosShaKOp3Zo+/jgFTDe+wcSfv0yFGfQaLX7tDO0reXOPRuMCG4Q11Y3IiYblWgzS7R+h31qdRtlGB7zikeUckz+AB3a8FuMqD7Cd2nhUHLOEIkLubQIkEuLxIdwEwUy3HyXxsbgPMJcGuGox+TSIugxuTQ+KHIaAS5N92eIIuMT5tJoPfHy5q9yKoXLelLuKRri0mjMQdhwTPw6Sv8pzKXhFyhNilEwkSCXRrnAnaPnJdyl0UrqXircpeHVglnv+62K4NJo3lFcGmWd79KO7OQoXAE8XNO6tIQGxj7fpfHTwk8RubQLWEGvgTNGKzj01fixunCMCCYcvSSlaFwUyKVx86J3bczpUR3zimq1LqdosAUbJF54ar+uk5Gju436mPTk8ZAXFdO93HRYTesUVgf3B+y0XdxLfdVputmfKp/iBtNjyl3c0kzUwtJIWewIPvAL9LOyWLsV9WAps3VRzh6hJBm3oOqsRKfHLGYzS/GP+iLBuBKdqkd+iWPkFZTHf4Em4us/uhI5qss/6zK5u8+AXpwAAAAASUVORK5CYII=" alt="꽃" width="47" height="50"> </a> <div class="service_info"> <strong class="title">프로젝트 꽃</strong> <a href="https://search.naver.com/search.naver?where=nexearch&sm=top_hty&fbm=1&ie=utf8&query=%ED%94%84%EB%A1%9C%EC%A0%9D%ED%8A%B8%EA%BD%83" class="dsc" data-clk="link">바로가기</a> </div> </div> </div> </div> <div class="corp_area" data-clk-prefix="plc"> <h3 class="blind">네이버 정책 및 약관</h3> <ul class="list_corp"> <li class="corp_item"><a href="https://www.navercorp.com" data-clk="intronhn">회사소개</a></li> <li class="corp_item"><a href="https://recruit.navercorp.com/naver/recruitMain" data-clk="recruit">인재채용</a></li> <li class="corp_item"><a href="https://www.navercorp.com/naver/proposalGuide" data-clk="contact">제휴제안</a></li> <li class="corp_item"><a href="/policy/service.html" data-clk="service">이용약관</a></li> <li class="corp_item"><a href="/policy/privacy.html" data-clk="privacy"><strong>개인정보처리방침</strong></a></li> <li class="corp_item"><a href="/policy/youthpolicy.html" data-clk="youth">청소년보호정책</a></li> <li class="corp_item"><a href="/policy/spamcheck.html" data-clk="policy">네이버 정책</a></li> <li class="corp_item"><a href="https://help.naver.com/" data-clk="helpcenter">고객센터</a></li> </ul> <address class="addr"><a href="https://www.navercorp.com" target="_blank" data-clk="nhn">ⓒ NAVER Corp.</a></address> </div> </div> </div> </div> <div id="adscript" style="display:none"></div> </body> </html>
