<?php
header("Content-Type","application/json; charset=utf-8");
$data = [
          'test' => 1,
          'test' => 2,
          'test' => 3,
];
echo json_encode($data); //json 데이터를 출력해주는 연습
