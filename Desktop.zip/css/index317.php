<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <!--<script>
      setTimeout(() => {
        location.herf='page.php';
      },3000);
    </script>-->
    <script>
      $(()=>{
        $.ajax({
          url:"page.php",
          type:"get",
          dataType:"html",
          success: function(res){
            $('body').html(res);
          },
          error: function(err){
            console.log(err);
          }
        });

        settimeout(()=>{
          $(()=>{
            $.ajax({
              url:"page2.php",
              type:"get",
              dataType:"html",
              success: function(res){
                $('body').html(res);
              },
              error: function(err){
                console.log(err);
              }
            });
        },5000);
      });
    });
    </script>
    <script>
      $((){
        $(".post").click(function(){
          const num = $(this).data("num");
          const url = `post/${num}.php`;
          $.ajax({
            url: url,
            type: "get",
            dataType : "json",
            //json(자바스크립트 객체), text
            success : function(res){
              //res -> 서버에서 온 데이터
              //$("#output").html(res);
            },
            error: function(err){
              console.error(err);
            }
          });
        });
      });
    </script>
  </head>
  <body>
    <div>
      <span class='post' data-num='1'>글1</span>
      <span class='post' data-num='2'>글2</span>
      <span class='post' data-num='3'>글3</span>
    </div>
    <div id="output"></div><!--원격페이지 내용을 출력-->
  </body>
</html>
