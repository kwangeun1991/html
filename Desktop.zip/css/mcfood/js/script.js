window.addEventListener('DOMContentLoaded', function(e) {
    var swiper = new Swiper('.main_banner .swiper-container', {
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      speed: 2000,
      loop: true,
      autoplay: {
        delay: 2000,
      },
    });


    var swiper = new Swiper('.swiper-container', {
      spaceBetween: 30,
      pagination: {
        el: '.swiper-pagination',
      },
      clickable: true,
      speed: 2000,
      loop: true,
      autoplay: {
        delay: 2000,}
    });


  },
  false);
