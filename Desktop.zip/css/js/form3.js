const goodsForm = {
  add : function() {
    $html = $('.form .car').first().clone();
    $('.form').append($html);
    const deleteBtn = '<button class="remove">삭제</button>';
    $html.find(".btn").append(deleteBtn);

    $html.find("input[type='text']").val('');
    $html.find("input[type='number']").val('');

    $html.find("input[type='radio']").prop("checked", false);
    $html.find("select").val('').change();
  },
  remove : function(thisObj) {
    thisObj.closest(".car").remove();
  }
};

$(() => {
  $('body').on('click','.btn .add',function(e){
    e.preventDefault();

    goodsForm.add();

  });

  $('body').on('click','.btn .remove', function(e){
    e.preventDefault();

    goodsForm.remove($(this));
  });
});
