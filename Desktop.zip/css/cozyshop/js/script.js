/*window.addEventListener('DOMContentLoaded', function(e) {
	var swiper = new Swiper('.swiper-container', {
		  pagination: {
			el: '.swiper-pagination',
		  },
		  navigation: {
			nextEl: '.swiper-button-next',
			prevEl: '.swiper-button-prev',
		  }
	});
}, false);*/

/*    온로드 로 작성하여 하는 방식도 있음 자바스크립드때 배우기*/
window.onload = function () {
	var swiper = new Swiper('.swiper-container', {
		  pagination: {
			el: '.swiper-pagination',
			clickable: true,
		  },
		  navigation: {
			nextEl: '.swiper-button-next',
			prevEl: '.swiper-button-prev',
		  },
		  loop: true
	});
}
