window.addEventListener('DOMContentLoaded', function(e) {
  /*메인배너롤링*/
  var swiperM = new Swiper('.main_banner .swiper-container', {
    navigation: {
      nextEl: '.main_banner .swiper-button-next',
      prevEl: '.main_banner .swiper-button-prev',
    },
    loop: true,
    autoplay: {
      delay: 3000,
    },
    pagination: {
      el: '.main_banner .swiper-pagination',
    },
  });

  var swiperE = new Swiper('.event_photo .swiper-container', {
    navigation: {
      nextEl: '.event_photo .swiper-button-next',
      prevEl: '.event_photo .swiper-button-prev',
    },
    loop: true,
    autoplay: {
      delay: 3000,
    },
    pagination: {
      el: '.event_photo .swiper-pagination',
    },
  });
}, false);
