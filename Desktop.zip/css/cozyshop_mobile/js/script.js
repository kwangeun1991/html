/*

html -> 구조 -> 스타일
특정요소중에서 동작이 필요한 부분

1. 클래스로 스타일정의
2. 스크립트로 동작 구현

1번 -> 현재가능



*/






window.addEventListener('DOMContentLoaded', function(e) {


  /* 메인배너 롤링 S */
var swiper = new Swiper('.swiper-container', {
     pagination: {
       el: '.swiper-pagination',
       clickable: true,
     },
     loop: true,
   });
   /* 메인배너 롤링 E */


/* 슬라이더 더보기 메뉴 S */

var showAside = document.querySelector(".show_aside"); // 더보기 버튼
var slideMenu = document.querySelector(".slide_menu"); // 슬라이드 메뉴
var layerDim = document.querySelector(".layer_dim"); // 레이어 BG

if(showAside){
  showAside.addEventListener("click",function(e){
  var clList = slideMenu.classList;
  var dim = layerDim.classList.remove("dn");
  if(clList.contains('on')){ // 슬라이드가 열려 있는 경우
    // 닫기
    clList.remove('on');
    layerDim.classList.add('dn');
  }else{ // 슬라이드가 닫혀 있는 경우
    // 열기
    clList.add('on');
  }
},false);
}
// 슬라이드 닫기
var closeBtn = document.querySelector('.slide_menu .close_btn');
if (closeBtn){
  closeBtn.addEventListener('click',function(e){
    console.log("click");
    slideMenu.classList.remove('on');
    layerDim.classList.remove('dn');
    layerDim.classList.add('dn');
  }, false);
}

   /* 슬라이더 더보기 메뉴 E */

/* 전체메뉴 - 서브메뉴 펼침처리 S */

  var mainMenu = document.querySelector('.all_category .menu1');
  if(mainMenu){
    mainMenu.addEventListener('click',function(e){
      if(mainMenu.classList.contains('on')){//서브메뉴 펼쳐있을때
        //서브메뉴 감춤처리
        mainMenu.classList.remove('on');
      } else{//서브메뉴 닫혀있을때
        //서브메뉴 펼침처리
        mainMenu.classList.add('on');
      }
    },false);
  }


/* 전체메뉴 - 서브메뉴 펼침처리 E */


}, false);
