body{ padding:0; margin:0;}

header { height: 150px; background-color: gray; }
section{ height: 800px; }
footer{ height: 200px; background-color:blue; }

.slide_open { position : fixed; top: 20px; right: 20px;}
.slide { width: 300px; background-color: #f8f8f8; border-right: 1px
solid #000000; position: fixed; height: 100%; top: 0; left: 0;}
